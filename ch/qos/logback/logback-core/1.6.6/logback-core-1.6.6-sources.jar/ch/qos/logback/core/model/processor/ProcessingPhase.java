/*
 * Logback: the reliable, generic, fast and flexible logging framework.
 * Copyright (C) 1999-2026, QOS.ch. All rights reserved.
 *
 * This program and the accompanying materials are dual-licensed under
 * either the terms of the Eclipse Public License v2.0 as published by
 * the Eclipse Foundation
 *
 *   or (per the licensee's choosing)
 *
 * under the terms of the GNU Lesser General Public License version 2.1
 * as published by the Free Software Foundation.
 */
package ch.qos.logback.core.model.processor;

/**
 * An enumeration of processing phases.
 * 
 * @author Ceki G&uuml;lc&uuml;
 * @since 1.3.0
 *
 */
public enum ProcessingPhase {
    FIRST,
    DEPENDENCY_ANALYSIS,
    SECOND;
}
