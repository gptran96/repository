/**
 * Logback: the reliable, generic, fast and flexible logging framework. Copyright (C) 1999-2015, QOS.ch. All rights
 * reserved.
 *
 * This program and the accompanying materials are dual-licensed under either the terms of the Eclipse Public License
 * v1.0 as published by the Eclipse Foundation
 *
 * or (per the licensee's choosing)
 *
 * under the terms of the GNU Lesser General Public License version 2.1 as published by the Free Software Foundation.
 */
package ch.qos.logback.core.rolling;

import java.io.File;
import java.time.Instant;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.Date;

import ch.qos.logback.core.joran.spi.NoAutoStart;
import ch.qos.logback.core.rolling.helper.TimeBasedArchiveRemover;

/**
 * Default implementation of {@link TimeBasedFileNamingAndTriggeringPolicy}
 * interface extending {@link TimeBasedFileNamingAndTriggeringPolicyBase}. This class is intended to be nested
 * within a {@link TimeBasedRollingPolicy}.
 *
 *
 * @author Ceki G&uuml;lc&uuml;
 *
 * @param <E>
 */
@NoAutoStart
public class DefaultTimeBasedFileNamingAndTriggeringPolicy<E> extends TimeBasedFileNamingAndTriggeringPolicyBase<E> {

    @Override
    public void start() {
        super.start();
        if (!super.isErrorFree())
            return;
        if (enclosingTBRP.fileNamePattern.hasIntegerTokenCOnverter()) {
            addError("Filename pattern [" + enclosingTBRP.fileNamePattern
                    + "] contains an integer token converter, i.e. %i, INCOMPATIBLE with this configuration. Please remove it.");
            return;
        }

        archiveRemover = new TimeBasedArchiveRemover(enclosingTBRP.fileNamePattern,
                enclosingTBRP.fileNamePatternWithoutCompSuffix, rc);
        archiveRemover.setContext(context);
        started = true;
    }

    public boolean isTriggeringEvent(File activeFile, final E event) {
        long currentTime = getCurrentTime();
        long localNextCheck = atomicNextCheck.get();
        if (currentTime >= localNextCheck) {
            long nextCheck = computeNextCheck(currentTime);
            atomicNextCheck.set(nextCheck);
            Instant instantOfElapsedPeriod = dateInCurrentPeriod;
            ZonedDateTime ztd = instantOfElapsedPeriod.atZone(zoneId);
            addInfo("Elapsed period: " + ztd.toString());
            this.elapsedPeriodsFileName = enclosingTBRP.fileNamePatternWithoutCompSuffix.convert(instantOfElapsedPeriod);
            setDateInCurrentPeriod(currentTime);
            return true;
        } else {
            return false;
        }
    }

    @Override
    public String toString() {
        return "c.q.l.core.rolling.DefaultTimeBasedFileNamingAndTriggeringPolicy";
    }

}
