package io.github.jdubois.bootui.core.dto;

import java.util.List;

/**
 * Aggregated Copilot dashboard payload. Counts are computed from sanitized
 * session metadata only; raw prompts, arguments, output, and diffs are never
 * included.
 */
public record CopilotDashboardDto(
        boolean available,
        String unavailableReason,
        String sessionStateDir,
        int sessionCount,
        int eventCount,
        int turnCount,
        Long totalInputTokens,
        Long totalOutputTokens,
        int errorCount,
        int activeLast24Hours,
        int activeLast7Days,
        int sessionsWithSchemaDrift,
        Long lastActivityEpochMillis,
        List<CopilotMetricCount> categoryCounts,
        List<CopilotMetricCount> modelCounts,
        List<CopilotMetricCount> topTools,
        int otherToolEventCount,
        List<CopilotActivityBucket> activityBuckets,
        List<CopilotActivityBucket> dailyActivityBuckets,
        List<CopilotSessionSummary> recentSessions,
        List<String> warnings) {

    public CopilotDashboardDto {
        categoryCounts = DtoCollections.immutableCopy(categoryCounts);
        modelCounts = DtoCollections.immutableCopy(modelCounts);
        topTools = DtoCollections.immutableCopy(topTools);
        activityBuckets = DtoCollections.immutableCopy(activityBuckets);
        dailyActivityBuckets = DtoCollections.immutableCopy(dailyActivityBuckets);
        recentSessions = DtoCollections.immutableCopy(recentSessions);
        warnings = DtoCollections.immutableCopy(warnings);
    }
}
