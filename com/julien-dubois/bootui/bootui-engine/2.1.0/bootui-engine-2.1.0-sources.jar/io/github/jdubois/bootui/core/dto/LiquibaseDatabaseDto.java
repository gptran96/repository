package io.github.jdubois.bootui.core.dto;

import java.util.List;

/**
 * Recorded change sets of one Liquibase bean (one managed database / change-log table).
 */
public record LiquibaseDatabaseDto(
        String name,
        int applied,
        int pending,
        int total,
        List<LiquibaseChangeSetDto> changeSets,
        boolean updateEnabled,
        String updateDisabledReason) {

    public LiquibaseDatabaseDto {
        changeSets = DtoCollections.immutableCopy(changeSets);
    }
}
