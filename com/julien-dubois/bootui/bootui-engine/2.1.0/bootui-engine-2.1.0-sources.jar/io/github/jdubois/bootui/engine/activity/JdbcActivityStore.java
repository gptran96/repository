package io.github.jdubois.bootui.engine.activity;

import io.github.jdubois.bootui.core.dto.ActivityEntryDto;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicBoolean;
import javax.sql.DataSource;

/**
 * Direct-JDBC {@link ActivityStore} implementation: a near-portable schema, one table shared by every BootUI
 * instance pointed at the same database (the {@code instance_id} column is the multi-tenant partition key), and
 * auto-creation on first use.
 *
 * <p>Every JDBC call this class makes runs inside {@link BootUiJdbcCaptureGuard#runSuppressed}, so it
 * can safely run over a {@code DataSource} that {@code SqlTraceRecorder} is also wrapping without
 * appearing in the SQL Trace panel or, worse, being captured back into this very store.</p>
 *
 * <p>Every statement is bounded by {@link #QUERY_TIMEOUT_SECONDS}: {@link BufferedActivityStore}'s
 * flush/prune scheduler is single-threaded, so one statement that hangs (for example a database that
 * stops responding mid-query rather than cleanly refusing the connection) would otherwise wedge every
 * future flush and prune forever, not just the one in progress; it also keeps the bounded final flush
 * {@link BufferedActivityStore#close()} attempts on shutdown meaningfully bounded rather than depending
 * on the JDBC driver alone to give up in time.</p>
 *
 * <p>The primary key is the client-assigned pair {@code (instance_id, seq)} rather than a database
 * identity/auto-increment column, and pagination is keyset-based on {@code (occurred_at, seq)}, not {@code OFFSET},
 * so it stays stable and fast on a table that is continuously appended to. Only two things differ by database, and
 * {@link ActivitySqlDialect} picks them once per store from the driver-reported product name: the 64-bit column type
 * ({@code NUMBER(19)} on Oracle, which has no {@code BIGINT}) and the row-limit clause ({@code LIMIT} on MySQL and
 * MariaDB, the SQL-standard {@code OFFSET ... FETCH FIRST} elsewhere). The store is tested against H2 and against
 * live PostgreSQL, MySQL, MariaDB and Oracle servers; SQL Server uses the standard forms but is not tested live.</p>
 */
public final class JdbcActivityStore implements ActivityStore {

    /**
     * Upper bound, in seconds, on any single statement this store executes (probe, DDL, insert,
     * select, delete). See the class-level note on why this matters beyond just this one call.
     */
    private static final int QUERY_TIMEOUT_SECONDS = 10;

    /** The column holding an entry's badges, added after the table's first release. */
    private static final String BADGES_COLUMN = "badges";

    /**
     * The one-row page read {@link #verifySchema()} runs to prove this database accepts the store's read statement.
     * It asks for an instance id no BootUI instance uses, and its result is discarded either way.
     */
    private static final ActivityQuery READ_PROBE = new ActivityQuery("", null, null, null, null, null, null, 1);

    private final DataSource dataSource;
    private final String tableName;
    private final AtomicBoolean schemaReady = new AtomicBoolean(false);
    private volatile ActivitySqlDialect dialect;

    /**
     * Whether the table has the {@code badges} column (M5-2). A table an earlier BootUI created gains it with one
     * {@code ALTER TABLE ... ADD}; when the database refuses, entries are stored and read without their badges.
     */
    private volatile boolean badgesColumn;

    public JdbcActivityStore(DataSource dataSource, String tableName) {
        this.dataSource = dataSource;
        this.tableName = validateTableName(tableName);
    }

    @Override
    public void appendBatch(List<StoredActivityEntry> entries) {
        if (entries == null || entries.isEmpty()) {
            return;
        }
        try {
            BootUiJdbcCaptureGuard.runSuppressed(() -> {
                ensureSchema();
                insertBatch(entries);
                return null;
            });
        } catch (Exception ex) {
            throw new ActivityStoreException("Failed to append " + entries.size() + " activity entries", ex);
        }
    }

    @Override
    public ActivityPage query(ActivityQuery query) {
        try {
            return BootUiJdbcCaptureGuard.runSuppressed(() -> {
                ensureSchema();
                return runQuery(query);
            });
        } catch (Exception ex) {
            throw new ActivityStoreException("Failed to query activity entries", ex);
        }
    }

    /**
     * Eagerly probes for and creates this store's table (if missing), then runs one bounded, read-only page query
     * of the exact shape reads use, for callers that want to fail fast with a clear error before committing to this
     * store — used by the Live Activity "use existing datasource" runtime switch (see {@code
     * ActivityStoreFactory#createAndVerifyDurable}) so an unreachable or misconfigured database, or one that
     * rejects the store's read statement, surfaces immediately as a rejected switch attempt rather than silently on
     * the first background flush or as a broken panel. Idempotent, like every other schema-touching call here: safe
     * to call even when the schema is already known-ready.
     */
    public void verifySchema() {
        try {
            BootUiJdbcCaptureGuard.runSuppressed(() -> {
                ensureSchema();
                runQuery(READ_PROBE);
                return null;
            });
        } catch (Exception ex) {
            throw new ActivityStoreException("Failed to verify/create or read the activity table", ex);
        }
    }

    @Override
    public void prune(String instanceId, long olderThanEpochMillis) {
        try {
            BootUiJdbcCaptureGuard.runSuppressed(() -> {
                ensureSchema();
                String sql = "DELETE FROM " + tableName + " WHERE instance_id = ? AND occurred_at < ?";
                try (Connection connection = dataSource.getConnection();
                        PreparedStatement statement = connection.prepareStatement(sql)) {
                    statement.setQueryTimeout(QUERY_TIMEOUT_SECONDS);
                    statement.setString(1, instanceId);
                    statement.setLong(2, olderThanEpochMillis);
                    statement.executeUpdate();
                }
                return null;
            });
        } catch (Exception ex) {
            throw new ActivityStoreException("Failed to prune activity entries", ex);
        }
    }

    /** Probes for the table and creates it (and its supporting index) if missing, racing safely. */
    private void ensureSchema() throws SQLException {
        if (schemaReady.get()) {
            return;
        }
        try (Connection connection = dataSource.getConnection()) {
            if (tableExists(connection)) {
                badgesColumn = ensureBadgesColumn(connection);
                schemaReady.set(true);
                return;
            }
            try (Statement statement = connection.createStatement()) {
                statement.setQueryTimeout(QUERY_TIMEOUT_SECONDS);
                statement.executeUpdate(createTableSql(dialect(connection).bigIntType()));
            } catch (SQLException createFailed) {
                // Another instance may have created the table concurrently (multi-tenant startup race).
                // Re-probe before giving up: the desired end state (table exists) is what matters, not
                // which instance won the race.
                if (!tableExists(connection)) {
                    throw createFailed;
                }
            }
            badgesColumn = ensureBadgesColumn(connection);
            try (Statement statement = connection.createStatement()) {
                statement.setQueryTimeout(QUERY_TIMEOUT_SECONDS);
                statement.executeUpdate(createIndexSql());
            } catch (SQLException indexFailed) {
                // The index is a performance aid, not a correctness requirement (e.g. it may already
                // exist from a concurrent creator, or the dialect names indexes differently); never fail
                // the whole store over it.
            }
            schemaReady.set(true);
        }
    }

    /** Whether the table has the {@code badges} column, adding it to a table an earlier BootUI created. */
    private boolean ensureBadgesColumn(Connection connection) {
        if (columnExists(connection, BADGES_COLUMN)) {
            return true;
        }
        try (Statement statement = connection.createStatement()) {
            statement.setQueryTimeout(QUERY_TIMEOUT_SECONDS);
            statement.executeUpdate("ALTER TABLE " + tableName + " ADD " + BADGES_COLUMN + " VARCHAR(128)");
        } catch (SQLException alterFailed) {
            // Another instance may have added it concurrently, or the database refuses the change: re-probe, and
            // without the column, keep the store working without badges.
        }
        return columnExists(connection, BADGES_COLUMN);
    }

    private boolean columnExists(Connection connection, String column) {
        try (Statement statement = connection.createStatement()) {
            statement.setQueryTimeout(QUERY_TIMEOUT_SECONDS);
            try (ResultSet ignored =
                    statement.executeQuery("SELECT " + column + " FROM " + tableName + " WHERE 1 = 0")) {
                return true;
            }
        } catch (SQLException notFound) {
            return false;
        }
    }

    private boolean tableExists(Connection connection) {
        try (Statement statement = connection.createStatement()) {
            statement.setQueryTimeout(QUERY_TIMEOUT_SECONDS);
            try (ResultSet ignored = statement.executeQuery("SELECT 1 FROM " + tableName + " WHERE 1 = 0")) {
                return true;
            }
        } catch (SQLException notFound) {
            return false;
        }
    }

    /**
     * This store's database dialect, detected from the first connection that needs it and cached: a store is bound
     * to one {@code DataSource}, so the answer never changes. Concurrent first calls may each detect it; they agree.
     */
    private ActivitySqlDialect dialect(Connection connection) throws SQLException {
        ActivitySqlDialect detected = dialect;
        if (detected == null) {
            detected = ActivitySqlDialect.detect(connection.getMetaData().getDatabaseProductName());
            dialect = detected;
        }
        return detected;
    }

    private String createTableSql(String bigInt) {
        return "CREATE TABLE "
                + tableName
                + " (" + "instance_id VARCHAR(64) NOT NULL, "
                + "seq " + bigInt + " NOT NULL, "
                + "entry_id VARCHAR(128) NOT NULL, "
                + "entry_type VARCHAR(16) NOT NULL, "
                + "occurred_at " + bigInt + " NOT NULL, "
                + "severity VARCHAR(16), "
                + "summary VARCHAR(1000), "
                + "detail VARCHAR(2000), "
                + "duration_ms " + bigInt + ", "
                + "correlation_id VARCHAR(64), "
                + "http_method VARCHAR(10), "
                + "path VARCHAR(512), "
                + "status_code INTEGER, "
                + "thread_name VARCHAR(128), "
                + "profileable INTEGER NOT NULL, "
                + "parent_entry_id VARCHAR(128), "
                + "secured_principal VARCHAR(256), "
                + "sql_n_plus_one_suspected INTEGER NOT NULL, "
                + BADGES_COLUMN + " VARCHAR(128), "
                + "PRIMARY KEY (instance_id, seq))";
    }

    private String createIndexSql() {
        return "CREATE INDEX idx_" + tableName + "_time ON " + tableName + " (instance_id, occurred_at, seq)";
    }

    private void insertBatch(List<StoredActivityEntry> entries) throws SQLException {
        boolean badges = badgesColumn;
        String sql = "INSERT INTO " + tableName + " (instance_id, seq, entry_id, entry_type, occurred_at, "
                + "severity, summary, detail, duration_ms, correlation_id, http_method, path, status_code, "
                + "thread_name, profileable, parent_entry_id, secured_principal, sql_n_plus_one_suspected"
                + (badges ? ", " + BADGES_COLUMN : "") + ") "
                + "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?" + (badges ? ", ?" : "") + ")";
        try (Connection connection = dataSource.getConnection();
                PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setQueryTimeout(QUERY_TIMEOUT_SECONDS);
            for (StoredActivityEntry stored : entries) {
                ActivityEntryDto entry = stored.entry();
                int i = 1;
                statement.setString(i++, stored.instanceId());
                statement.setLong(i++, stored.seq());
                statement.setString(i++, entry.id());
                statement.setString(i++, entry.type());
                statement.setLong(i++, entry.timestamp());
                statement.setString(i++, entry.severity());
                statement.setString(i++, entry.summary());
                statement.setString(i++, entry.detail());
                setNullableLong(statement, i++, entry.durationMs());
                statement.setString(i++, entry.correlationId());
                statement.setString(i++, entry.method());
                statement.setString(i++, entry.path());
                setNullableInt(statement, i++, entry.status());
                statement.setString(i++, entry.thread());
                statement.setInt(i++, entry.profileable() ? 1 : 0);
                statement.setString(i++, entry.parentId());
                statement.setString(i++, entry.securedPrincipal());
                statement.setInt(i++, entry.sqlNPlusOneSuspected() ? 1 : 0);
                if (badges) {
                    statement.setString(i++, encodeBadges(entry.badges()));
                }
                statement.addBatch();
            }
            statement.executeBatch();
        }
    }

    private ActivityPage runQuery(ActivityQuery query) throws SQLException {
        boolean badges = badgesColumn;
        StringBuilder sql = new StringBuilder("SELECT instance_id, seq, entry_id, entry_type, occurred_at, "
                + "severity, summary, detail, duration_ms, correlation_id, http_method, path, status_code, "
                + "thread_name, profileable, parent_entry_id, secured_principal, sql_n_plus_one_suspected"
                + (badges ? ", " + BADGES_COLUMN : "") + " FROM "
                + tableName
                + " WHERE instance_id = ?");
        List<Object> params = new ArrayList<>();
        params.add(query.instanceId());

        if (query.normalizedType() != null) {
            sql.append(" AND UPPER(entry_type) = ?");
            params.add(query.normalizedType().toUpperCase(java.util.Locale.ROOT));
        }
        if (query.normalizedSeverity() != null) {
            sql.append(" AND UPPER(severity) = ?");
            params.add(query.normalizedSeverity().toUpperCase(java.util.Locale.ROOT));
        }
        if (query.normalizedText() != null) {
            String needle = "%" + query.normalizedText().toUpperCase(java.util.Locale.ROOT) + "%";
            sql.append(" AND (UPPER(summary) LIKE ? OR UPPER(detail) LIKE ? OR UPPER(path) LIKE ? "
                    + "OR UPPER(http_method) LIKE ?)");
            params.add(needle);
            params.add(needle);
            params.add(needle);
            params.add(needle);
        }
        if (query.since() != null) {
            sql.append(" AND occurred_at > ?");
            params.add(query.since());
        }
        if (query.until() != null) {
            sql.append(" AND occurred_at <= ?");
            params.add(query.until());
        }
        ActivityCursor cursor = ActivityCursor.decode(query.cursor());
        if (cursor != null) {
            sql.append(" AND (occurred_at < ? OR (occurred_at = ? AND seq < ?))");
            params.add(cursor.timestamp());
            params.add(cursor.timestamp());
            params.add(cursor.seq());
        }
        sql.append(" ORDER BY occurred_at DESC, seq DESC");
        int limit = query.pageSize() + 1;
        params.add(limit);

        List<StoredActivityEntry> matches = new ArrayList<>();
        try (Connection connection = dataSource.getConnection();
                PreparedStatement statement =
                        connection.prepareStatement(sql + dialect(connection).rowLimitClause())) {
            statement.setQueryTimeout(QUERY_TIMEOUT_SECONDS);
            for (int i = 0; i < params.size(); i++) {
                statement.setObject(i + 1, params.get(i));
            }
            try (ResultSet rs = statement.executeQuery()) {
                while (rs.next()) {
                    matches.add(toStoredEntry(rs, badges));
                }
            }
        }

        boolean hasMore = matches.size() > query.pageSize();
        List<StoredActivityEntry> page = hasMore ? matches.subList(0, query.pageSize()) : matches;
        String nextCursor = null;
        if (hasMore) {
            StoredActivityEntry last = page.get(page.size() - 1);
            nextCursor = new ActivityCursor(last.entry().timestamp(), last.seq()).encode();
        }
        return new ActivityPage(page, nextCursor, hasMore);
    }

    private StoredActivityEntry toStoredEntry(ResultSet rs, boolean badges) throws SQLException {
        String instanceId = rs.getString("instance_id");
        long seq = rs.getLong("seq");
        ActivityEntryDto entry = new ActivityEntryDto(
                rs.getString("entry_id"),
                rs.getString("entry_type"),
                rs.getLong("occurred_at"),
                rs.getString("severity"),
                rs.getString("summary"),
                rs.getString("detail"),
                getNullableLong(rs, "duration_ms"),
                rs.getString("correlation_id"),
                rs.getString("http_method"),
                rs.getString("path"),
                getNullableInt(rs, "status_code"),
                rs.getString("thread_name"),
                rs.getInt("profileable") != 0,
                rs.getString("parent_entry_id"),
                rs.getString("secured_principal"),
                rs.getInt("sql_n_plus_one_suspected") != 0,
                badges ? decodeBadges(rs.getString(BADGES_COLUMN)) : List.of(),
                exceptionGroupId(rs.getString("entry_type"), rs.getString("entry_id")));
        return new StoredActivityEntry(instanceId, seq, entry);
    }

    /**
     * A stored {@code EXCEPTION} entry's group id, read back from the {@code exc-} id the buffers' feed gives it; an
     * exception entry the journal's feed stored has no column for it, so {@code null}.
     */
    static String exceptionGroupId(String type, String id) {
        return "EXCEPTION".equals(type) && id != null && id.startsWith(EXCEPTION_ID_PREFIX) && id.length() > 4
                ? id.substring(EXCEPTION_ID_PREFIX.length())
                : null;
    }

    private static final String EXCEPTION_ID_PREFIX = "exc-";

    /** An entry's badges, comma-separated (each is an upper-case identifier), or {@code null} when it has none. */
    static String encodeBadges(List<String> badges) {
        if (badges == null || badges.isEmpty()) {
            return null;
        }
        List<String> kept = new ArrayList<>(badges.size());
        for (String badge : badges) {
            if (badge != null && !badge.isBlank() && badge.indexOf(',') < 0) {
                kept.add(badge.trim());
            }
        }
        return kept.isEmpty() ? null : String.join(",", kept);
    }

    static List<String> decodeBadges(String stored) {
        if (stored == null || stored.isBlank()) {
            return List.of();
        }
        List<String> badges = new ArrayList<>();
        for (String badge : stored.split(",")) {
            if (!badge.isBlank()) {
                badges.add(badge.trim());
            }
        }
        return badges;
    }

    private static void setNullableLong(PreparedStatement statement, int index, Long value) throws SQLException {
        if (value == null) {
            statement.setNull(index, java.sql.Types.BIGINT);
        } else {
            statement.setLong(index, value);
        }
    }

    private static void setNullableInt(PreparedStatement statement, int index, Integer value) throws SQLException {
        if (value == null) {
            statement.setNull(index, java.sql.Types.INTEGER);
        } else {
            statement.setInt(index, value);
        }
    }

    private static Long getNullableLong(ResultSet rs, String column) throws SQLException {
        long value = rs.getLong(column);
        return rs.wasNull() ? null : value;
    }

    private static Integer getNullableInt(ResultSet rs, String column) throws SQLException {
        int value = rs.getInt(column);
        return rs.wasNull() ? null : value;
    }

    /**
     * Guards against SQL injection through a misconfigured {@code bootui.activity.persistence.table-name}:
     * only identifier characters are allowed, since the table name is concatenated directly into DDL/DML
     * (JDBC has no parameter-binding for identifiers).
     */
    private static String validateTableName(String tableName) {
        if (tableName == null || !tableName.matches("[A-Za-z_][A-Za-z0-9_]*")) {
            throw new IllegalArgumentException(
                    "bootui.activity.persistence.table-name must be a plain SQL identifier, was: " + tableName);
        }
        return tableName;
    }
}
