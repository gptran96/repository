package io.github.jdubois.bootui.engine.architecture;

import com.tngtech.archunit.core.domain.JavaClasses;
import io.github.jdubois.bootui.core.dto.AdvisorEvidenceDto;
import io.github.jdubois.bootui.core.dto.AdvisorRuleViolationsDto;
import io.github.jdubois.bootui.core.dto.AdvisorViolationLocationDto;
import io.github.jdubois.bootui.core.dto.ArchitectureReport;
import io.github.jdubois.bootui.core.dto.ArchitectureRuleResultDto;
import io.github.jdubois.bootui.core.dto.ArchitectureScanStatusDto;
import io.github.jdubois.bootui.core.dto.ArchitectureSeverityCountDto;
import io.github.jdubois.bootui.engine.action.ActionOperations;
import io.github.jdubois.bootui.engine.action.SingleFlightAction;
import io.github.jdubois.bootui.engine.advisor.AdvisorLocations;
import io.github.jdubois.bootui.engine.advisor.AdvisorScanState;
import io.github.jdubois.bootui.engine.advisor.AdvisorViolationCollector;
import io.github.jdubois.bootui.engine.archunit.ArchUnitSourceLocations;
import io.github.jdubois.bootui.engine.progress.OperationProgress;
import io.github.jdubois.bootui.engine.progress.ProgressPhase;
import io.github.jdubois.bootui.engine.support.SeverityOrder;
import java.time.Clock;
import java.util.Collection;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.function.BiFunction;
import java.util.function.Function;
import java.util.function.IntSupplier;
import java.util.function.Supplier;

/**
 * Bounded, on-demand ArchUnit hygiene scanner.
 *
 * <p>The scanner imports only the host application's own classes (bounded to the detected
 * {@code @SpringBootApplication} base packages) and runs a fixed registry of curated, project-
 * agnostic architecture rules. Results are heuristic review prompts, not architectural verdicts.</p>
 */
public final class ArchitectureScanner {

    private static final String ANALYZER = "BootUI ArchUnit hygiene";
    private static final String DISCLAIMER =
            "Heuristic, project-agnostic architecture rules run against the host application's own classes only. "
                    + "These checks complement, but do not replace, a project-specific ArchUnit test suite or an "
                    + "architecture review.";
    private static final Comparator<ArchitectureRuleResultDto> IMPORTANCE_ORDER = Comparator.comparingInt(
                    (ArchitectureRuleResultDto result) -> SeverityOrder.rank(result.severity()))
            .thenComparing(Comparator.comparingInt(ArchitectureRuleResultDto::violationCount)
                    .reversed())
            .thenComparing(ArchitectureRuleResultDto::id);

    private final Supplier<List<String>> basePackagesSupplier;
    private final ArchitectureClassImporter importer;
    private final ArchitecturePlatform platform;
    private final Clock clock;
    static final ProgressPhase IMPORTING_CLASSES = ProgressPhase.of("Importing application classes");
    static final ProgressPhase CHECKING_GENERATED_CODE = ProgressPhase.of("Checking generated code");
    static final ProgressPhase EVALUATING_RULES = ProgressPhase.of("Evaluating architecture rules");
    static final ProgressPhase LOCATING_VIOLATIONS = ProgressPhase.of("Locating violations");

    private final List<ArchitectureRule> rules;
    private final Function<JavaClasses, ArchitectureGeneratedCode.Result> generatedCodeResolver;
    private final BiFunction<JavaClasses, Collection<AdvisorViolationLocationDto>, AdvisorLocations.Resolution>
            sourceLocations;
    private final SingleFlightAction singleFlight = new SingleFlightAction();
    private final AdvisorScanState<ArchitectureReport> violationState =
            new AdvisorScanState<>(ArchitectureReport::withViolationDetails, this::ruleCatalog);

    ArchitectureScanner(
            Supplier<List<String>> basePackagesSupplier,
            ArchitectureClassImporter importer,
            ArchitecturePlatform platform,
            Clock clock) {
        this(basePackagesSupplier, importer, platform, clock, ArchitectureRuleRegistry.activeRules());
    }

    ArchitectureScanner(
            Supplier<List<String>> basePackagesSupplier,
            ArchitectureClassImporter importer,
            ArchitecturePlatform platform,
            Clock clock,
            List<ArchitectureRule> rules) {
        this(basePackagesSupplier, importer, platform, clock, rules, ArchitectureGeneratedCode::resolve);
    }

    ArchitectureScanner(
            Supplier<List<String>> basePackagesSupplier,
            ArchitectureClassImporter importer,
            ArchitecturePlatform platform,
            Clock clock,
            List<ArchitectureRule> rules,
            Function<JavaClasses, ArchitectureGeneratedCode.Result> generatedCodeResolver) {
        this(
                basePackagesSupplier,
                importer,
                platform,
                clock,
                rules,
                generatedCodeResolver,
                ArchUnitSourceLocations::resolve);
    }

    ArchitectureScanner(
            Supplier<List<String>> basePackagesSupplier,
            ArchitectureClassImporter importer,
            ArchitecturePlatform platform,
            Clock clock,
            List<ArchitectureRule> rules,
            Function<JavaClasses, ArchitectureGeneratedCode.Result> generatedCodeResolver,
            BiFunction<JavaClasses, Collection<AdvisorViolationLocationDto>, AdvisorLocations.Resolution>
                    sourceLocations) {
        this.sourceLocations = sourceLocations;
        this.basePackagesSupplier = basePackagesSupplier;
        this.importer = importer;
        this.platform = platform;
        this.clock = clock;
        this.rules = List.copyOf(rules);
        this.generatedCodeResolver = generatedCodeResolver;
    }

    /**
     * Builds a scanner that imports the host application's compiled classes from the classpath, bounded
     * to the supplied base packages. This is the entry point adapters wire: the base packages are read
     * <em>live</em> on every scan (the supplier is typically backed by a {@code BasePackageProvider} SPI),
     * and the ArchUnit import runs only on demand, never at construction.
     */
    public static ArchitectureScanner usingClasspath(
            Supplier<List<String>> basePackagesSupplier, ArchitecturePlatform platform, Clock clock) {
        return new ArchitectureScanner(basePackagesSupplier, new ClassFileArchitectureImporter(), platform, clock);
    }

    /**
     * Builds a Spring-platform scanner, preserving the original public factory contract.
     *
     * @see #usingClasspath(Supplier, ArchitecturePlatform, Clock)
     */
    public static ArchitectureScanner usingClasspath(Supplier<List<String>> basePackagesSupplier, Clock clock) {
        return usingClasspath(basePackagesSupplier, ArchitecturePlatform.SPRING, clock);
    }

    public ArchitectureReport initialReport() {
        List<String> basePackages;
        try {
            basePackages = basePackages();
        } catch (RuntimeException | LinkageError ex) {
            return failure("Application base packages could not be detected", ex, null, List.of());
        }
        return report(
                "NOT_SCANNED",
                "Architecture rules have not run yet. Run architecture checks in the panel, or call architecture_scan"
                        + " (bootui architecture scan), to analyse the application classes.",
                null,
                basePackages,
                0,
                0,
                List.of());
    }

    public ArchitectureReport scan() {
        return singleFlight.run(ActionOperations.ARCHITECTURE_SCAN, () -> {
            AdvisorViolationCollector collector = violationState.collector();
            ArchitectureReport report = doScan(collector);
            // An interrupt can surface as an unreadable source file or an early return rather than at a checkpoint;
            // a scan its caller abandoned must never replace the previous report.
            OperationProgress.current().checkCancelled();
            return violationState.publish(report, collector);
        });
    }

    public ArchitectureReport lastReport() {
        return violationState.currentReport(this::initialReport);
    }

    public AdvisorRuleViolationsDto ruleViolations(String ruleId, String scanId, Integer offset, Integer limit) {
        return violationState.ruleViolations(ruleId, scanId, offset, limit);
    }

    public void setViolationRetentionLimit(IntSupplier limit) {
        violationState.setRetentionLimit(limit);
    }

    private ArchitectureReport doScan(AdvisorViolationCollector collector) {
        List<String> basePackages;
        try {
            basePackages = basePackages();
        } catch (RuntimeException | LinkageError ex) {
            return failure("Application base packages could not be detected", ex, clock.millis(), List.of());
        }
        if (basePackages.isEmpty()) {
            return report(
                    "SCANNED",
                    "No application base package was detected, so there were no classes to analyse.",
                    clock.millis(),
                    basePackages,
                    0,
                    0,
                    List.of());
        }

        // Units: the import, the generated-code check, each rule, and locating violations. Locating is reported when it
        // starts, short of the total: the final response, not a progress notification, marks completion.
        OperationProgress progress = OperationProgress.current();
        double total = rules.size() + 3;
        progress.checkCancelled();
        progress.report(IMPORTING_CLASSES, 0, total);
        JavaClasses classes;
        try {
            classes = Objects.requireNonNull(importer.importPackages(basePackages));
            // Catch LinkageError (e.g. NoClassDefFoundError/ClassFormatError) as well as RuntimeException so a
            // malformed or unresolvable class on the host classpath degrades to a stable report instead of failing.
            // VirtualMachineError (OutOfMemoryError, StackOverflowError) is deliberately not caught here.
        } catch (RuntimeException | LinkageError ex) {
            return failure("Application classes could not be imported for analysis", ex, clock.millis(), basePackages);
        }

        if (classes.isEmpty()) {
            return report(
                    "SCANNED",
                    "No application classes were found under the detected base package(s) to analyse.",
                    clock.millis(),
                    basePackages,
                    0,
                    0,
                    List.of(),
                    new AdvisorEvidenceDto(false, true, List.of()));
        }

        progress.checkCancelled();
        progress.report(CHECKING_GENERATED_CODE, 1, total);
        ArchitectureGeneratedCode.Result generatedCode;
        try {
            generatedCode = Objects.requireNonNull(generatedCodeResolver.apply(classes));
        } catch (RuntimeException | LinkageError ex) {
            generatedCode = new ArchitectureGeneratedCode.Result(
                    Set.of(),
                    List.of("Generated-source lookup failed (" + ex.getClass().getSimpleName()
                            + "); uncertain classes remain included."));
        }
        ArchitectureContext context = new ArchitectureContext(
                classes,
                basePackages,
                platform,
                new ArchitectureContext.ArchitectureEvaluationEvidence(),
                collector,
                generatedCode.handwrittenClasses(classes));
        List<ArchitectureRuleResultDto> results = new java.util.ArrayList<>();
        boolean usable = false;
        List<String> unreported = new java.util.ArrayList<>(generatedCode.limitations());
        progress.report(EVALUATING_RULES, 2, total);
        int evaluated = 0;
        for (ArchitectureRule rule : rules) {
            progress.checkCancelled();
            context.evidence().reset();
            ArchitectureRuleResultDto result = rule.evaluate(context);
            results.add(result);
            if (!context.evidence().evaluated() && !ArchitectureRuleSupport.ERROR.equals(result.status())) {
                unreported.add(result.id() + ": evaluator did not supply observation evidence.");
            }
            if (context.evidence().requiredUnknown()) {
                unreported.add(result.id() + ": required architecture observations could not be resolved.");
            }
            usable |= context.evidence().usable();
            if (++evaluated < rules.size()) {
                progress.report(EVALUATING_RULES, 2 + evaluated, total);
            }
        }
        progress.checkCancelled();
        progress.report(LOCATING_VIOLATIONS, 2 + rules.size(), total);
        results = completeLocations(classes, results, collector);
        long errors = results.stream()
                .filter(result -> ArchitectureRuleSupport.ERROR.equals(result.status()))
                .count();
        boolean hasSuccessfulEvaluation = results.stream()
                .anyMatch(result -> ArchitectureRuleSupport.PASS.equals(result.status()) || isViolation(result));
        String status = errors == 0 ? "SCANNED" : hasSuccessfulEvaluation ? "PARTIAL" : "ERROR";
        String message = errors == 0
                ? "Architecture rules completed against " + classes.size()
                        + " application class(es) under the detected base package(s)."
                : "Architecture analysis is incomplete: " + errors + " rule(s) could not be evaluated against "
                        + classes.size() + " application class(es).";
        if (!generatedCode.limitations().isEmpty()) {
            if (errors == 0) status = "PARTIAL";
            message += " Generated-code provenance is incomplete; uncertain classes remain included.";
        }
        int templateClasses = generatedCode.templateClasses().size();
        if (templateClasses > 0) {
            message += " " + templateClasses + " class(es) without local source provenance matched the OpenAPI"
                    + " Generator ApiUtil template and were excluded from coding checks.";
        }

        List<String> limitations = java.util.stream.Stream.concat(
                        unreported.stream(),
                        results.stream()
                                .filter(result -> ArchitectureRuleSupport.ERROR.equals(result.status()))
                                .map(result -> result.id() + ": architecture evaluation failed."))
                .limit(20)
                .toList();
        return report(
                status,
                message,
                clock.millis(),
                basePackages,
                classes.size(),
                results.size(),
                results,
                new AdvisorEvidenceDto(usable, errors == 0 && unreported.isEmpty(), limitations));
    }

    /**
     * Resolves source paths and verifies lines once, after every rule, for the samples and the retained details
     * alike. Only an explicit scan reaches this; detail reads serve the published records unchanged.
     */
    private List<ArchitectureRuleResultDto> completeLocations(
            JavaClasses classes, List<ArchitectureRuleResultDto> results, AdvisorViolationCollector collector) {
        return AdvisorLocations.complete(
                collector,
                results,
                ArchitectureRuleResultDto::sampleLocations,
                ArchitectureRuleResultDto::withSampleLocations,
                located -> sourceLocations.apply(classes, located));
    }

    private List<String> basePackages() {
        List<String> packages = List.copyOf(basePackagesSupplier.get());
        if (packages.stream().anyMatch(ArchitectureScanner::invalidPackage)) {
            throw new IllegalArgumentException("Invalid application base package.");
        }
        return packages;
    }

    private static boolean invalidPackage(String name) {
        // JVM package segments need not be Java identifiers (for example, escaped Kotlin names).
        for (String segment : name.split("\\.", -1)) {
            if (segment.isBlank()
                    || segment.chars().anyMatch(c -> "/\\;[*".indexOf(c) >= 0 || Character.isISOControl(c))) {
                return true;
            }
        }
        return false;
    }

    private ArchitectureReport failure(String message, Throwable error, Long scannedAt, List<String> basePackages) {
        return report(
                "ERROR",
                ArchitectureRuleSupport.detail(message + " (" + error.getClass().getSimpleName() + ")."),
                scannedAt,
                basePackages,
                0,
                0,
                List.of());
    }

    private ArchitectureReport report(
            String status,
            String message,
            Long scannedAt,
            List<String> basePackages,
            int classesAnalyzed,
            int rulesEvaluated,
            List<ArchitectureRuleResultDto> results) {
        return report(
                status,
                message,
                scannedAt,
                basePackages,
                classesAnalyzed,
                rulesEvaluated,
                results,
                AdvisorEvidenceDto.unknown());
    }

    private ArchitectureReport report(
            String status,
            String message,
            Long scannedAt,
            List<String> basePackages,
            int classesAnalyzed,
            int rulesEvaluated,
            List<ArchitectureRuleResultDto> results,
            AdvisorEvidenceDto evidence) {
        List<ArchitectureRuleResultDto> violations = violationResults(results);
        int violationsFound = violations.size();
        ArchitectureScanStatusDto scan = new ArchitectureScanStatusDto(
                ANALYZER, status, message, scannedAt, rulesEvaluated, classesAnalyzed, violationsFound);
        return new ArchitectureReport(
                true,
                DISCLAIMER,
                basePackages,
                classesAnalyzed,
                rulesEvaluated,
                violationsFound,
                severityCounts(violations),
                scan,
                violations,
                analysisErrors(results),
                evidence);
    }

    public ArchitectureReport applyDismissals(ArchitectureReport report, Set<String> dismissedIds) {
        if (report == null || dismissedIds == null || dismissedIds.isEmpty()) {
            return report;
        }
        List<ArchitectureRuleResultDto> marked = report.results().stream()
                .map(result -> result.withDismissed(dismissedIds.contains(result.id())))
                .toList();
        List<ArchitectureRuleResultDto> active =
                marked.stream().filter(result -> !result.dismissed()).toList();
        int violationsFound = active.size();
        ArchitectureScanStatusDto scan = report.scan();
        ArchitectureScanStatusDto updatedScan = new ArchitectureScanStatusDto(
                scan.analyzer(),
                scan.status(),
                scan.message(),
                scan.scannedAt(),
                scan.rulesEvaluated(),
                scan.classesAnalyzed(),
                violationsFound);
        return new ArchitectureReport(
                report.localOnly(),
                report.disclaimer(),
                report.basePackages(),
                report.classesAnalyzed(),
                report.rulesEvaluated(),
                violationsFound,
                severityCounts(active),
                updatedScan,
                marked,
                report.analysisErrors(),
                report.evidence(),
                report.violationDetails());
    }

    static List<ArchitectureRuleResultDto> analysisErrors(List<ArchitectureRuleResultDto> results) {
        return results.stream()
                .filter(result -> ArchitectureRuleSupport.ERROR.equals(result.status()))
                .sorted(Comparator.comparing(ArchitectureRuleResultDto::id))
                .toList();
    }

    private List<ArchitectureSeverityCountDto> severityCounts(List<ArchitectureRuleResultDto> results) {
        Map<String, Integer> counts = SeverityOrder.occurrenceCounts(
                results,
                ArchitectureScanner::isViolation,
                ArchitectureRuleResultDto::severity,
                ArchitectureRuleResultDto::violationCount);
        return counts.entrySet().stream()
                .map(entry -> new ArchitectureSeverityCountDto(entry.getKey(), entry.getValue()))
                .toList();
    }

    private List<ArchitectureRuleResultDto> violationResults(List<ArchitectureRuleResultDto> results) {
        return results.stream()
                .filter(ArchitectureScanner::isViolation)
                .sorted(IMPORTANCE_ORDER)
                .toList();
    }

    private static boolean isViolation(ArchitectureRuleResultDto result) {
        return ArchitectureRuleSupport.VIOLATION.equals(result.status());
    }

    /** The ids of the rules this scanner runs, the catalogue its detail reads know. */
    private List<String> ruleCatalog() {
        return AdvisorScanState.ruleIds(rules, rule -> rule.definition().id());
    }
}
