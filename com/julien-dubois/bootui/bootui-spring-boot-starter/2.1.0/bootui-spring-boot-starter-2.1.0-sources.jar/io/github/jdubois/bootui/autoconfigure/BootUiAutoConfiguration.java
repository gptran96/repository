package io.github.jdubois.bootui.autoconfigure;

import io.github.jdubois.bootui.autoconfigure.activity.LiveActivityController;
import io.github.jdubois.bootui.autoconfigure.activity.LiveServiceMapController;
import io.github.jdubois.bootui.autoconfigure.activity.RequestCorrelationFilter;
import io.github.jdubois.bootui.autoconfigure.activity.RequestCorrelationRegistry;
import io.github.jdubois.bootui.autoconfigure.activity.RequestPhaseInterceptor;
import io.github.jdubois.bootui.autoconfigure.activity.RequestPhaseResponseBodyAdvice;
import io.github.jdubois.bootui.autoconfigure.activity.SecurityEventCorrelationRegistry;
import io.github.jdubois.bootui.autoconfigure.activity.ServletThreadKinds;
import io.github.jdubois.bootui.autoconfigure.architecture.ArchitectureController;
import io.github.jdubois.bootui.autoconfigure.cli.BootUiCliController;
import io.github.jdubois.bootui.autoconfigure.cli.BootUiCliServiceFactory;
import io.github.jdubois.bootui.autoconfigure.config.BootUiExposure;
import io.github.jdubois.bootui.autoconfigure.config.BootUiPathPropertySource;
import io.github.jdubois.bootui.autoconfigure.config.ConfigOverrideService;
import io.github.jdubois.bootui.autoconfigure.crac.CracController;
import io.github.jdubois.bootui.autoconfigure.databaseadvisor.DatabaseAdvisorController;
import io.github.jdubois.bootui.autoconfigure.exceptions.BootUiExceptionHandlerResolver;
import io.github.jdubois.bootui.autoconfigure.exceptions.BootUiExceptionLogAppender;
import io.github.jdubois.bootui.autoconfigure.exceptions.ExceptionsController;
import io.github.jdubois.bootui.autoconfigure.graalvm.GraalVmController;
import io.github.jdubois.bootui.autoconfigure.hibernate.HibernateController;
import io.github.jdubois.bootui.autoconfigure.hibernate.HibernateStatisticsController;
import io.github.jdubois.bootui.autoconfigure.idle.ConsoleActivityFilter;
import io.github.jdubois.bootui.autoconfigure.idle.ConsoleActivityTracker;
import io.github.jdubois.bootui.autoconfigure.idle.IdleBuffersLowFootprint;
import io.github.jdubois.bootui.autoconfigure.idle.IdleReclaimable;
import io.github.jdubois.bootui.autoconfigure.insights.RuntimeInsightsController;
import io.github.jdubois.bootui.autoconfigure.javaagent.CodeInventoryController;
import io.github.jdubois.bootui.autoconfigure.javaagent.CodePathsController;
import io.github.jdubois.bootui.autoconfigure.javaagent.JavaAgentController;
import io.github.jdubois.bootui.autoconfigure.javaagent.SideEffectsController;
import io.github.jdubois.bootui.autoconfigure.jms.JmsController;
import io.github.jdubois.bootui.autoconfigure.kafka.KafkaController;
import io.github.jdubois.bootui.autoconfigure.mail.BootUiMailSenderBeanPostProcessor;
import io.github.jdubois.bootui.autoconfigure.mail.EmailController;
import io.github.jdubois.bootui.autoconfigure.mcp.BootUiMcpController;
import io.github.jdubois.bootui.autoconfigure.mcp.BootUiMcpService;
import io.github.jdubois.bootui.autoconfigure.mcp.BootUiMcpTools;
import io.github.jdubois.bootui.autoconfigure.mcp.McpServerController;
import io.github.jdubois.bootui.autoconfigure.mcp.McpServerState;
import io.github.jdubois.bootui.autoconfigure.mcp.SpringMcpPanelPolicy;
import io.github.jdubois.bootui.autoconfigure.memory.MemoryController;
import io.github.jdubois.bootui.autoconfigure.monitoring.BootUiSelfDataFilter;
import io.github.jdubois.bootui.autoconfigure.mysql.MySqlController;
import io.github.jdubois.bootui.autoconfigure.otlp.OtlpSpanDecoder;
import io.github.jdubois.bootui.autoconfigure.otlp.SpringTelemetrySettings;
import io.github.jdubois.bootui.autoconfigure.pentesting.*;
import io.github.jdubois.bootui.autoconfigure.postgres.PostgresqlController;
import io.github.jdubois.bootui.autoconfigure.rabbit.RabbitController;
import io.github.jdubois.bootui.autoconfigure.restapi.RestApiController;
import io.github.jdubois.bootui.autoconfigure.restclienttrace.RestClientTraceController;
import io.github.jdubois.bootui.autoconfigure.safety.ApiAuthenticationFilter;
import io.github.jdubois.bootui.autoconfigure.safety.LegacyBootUiPathFilter;
import io.github.jdubois.bootui.autoconfigure.safety.LocalhostOnlyFilter;
import io.github.jdubois.bootui.autoconfigure.safety.PanelAccessFilter;
import io.github.jdubois.bootui.autoconfigure.safety.SecurityHeadersFilter;
import io.github.jdubois.bootui.autoconfigure.security.SecurityController;
import io.github.jdubois.bootui.autoconfigure.spring.SpringController;
import io.github.jdubois.bootui.autoconfigure.sqltrace.SqlTraceController;
import io.github.jdubois.bootui.autoconfigure.sqltrace.SqlTraceDataSourceBeanPostProcessor;
import io.github.jdubois.bootui.autoconfigure.sqltrace.SqlTraceRuntimeHints;
import io.github.jdubois.bootui.autoconfigure.transactions.BootUiTransactionExecutionListener;
import io.github.jdubois.bootui.autoconfigure.transactions.BootUiTransactionManagerListenerRegistrar;
import io.github.jdubois.bootui.autoconfigure.transactions.TransactionsController;
import io.github.jdubois.bootui.autoconfigure.web.*;
import io.github.jdubois.bootui.autoconfigure.websocket.BootUiWebSocketCaptureConfigurer;
import io.github.jdubois.bootui.autoconfigure.websocket.BootUiWebSocketSessionRegistry;
import io.github.jdubois.bootui.autoconfigure.websocket.SpringWebSocketMetadataProvider;
import io.github.jdubois.bootui.autoconfigure.websocket.WebSocketController;
import io.github.jdubois.bootui.engine.advisor.DismissedRulesStore;
import io.github.jdubois.bootui.engine.cli.CliService;
import io.github.jdubois.bootui.engine.correlation.RequestPhases;
import io.github.jdubois.bootui.engine.exceptions.ExceptionStore;
import io.github.jdubois.bootui.engine.javaagent.AgentThreadLocals;
import io.github.jdubois.bootui.engine.journal.RuntimeJournal;
import io.github.jdubois.bootui.engine.memory.LowFootprintService;
import io.github.jdubois.bootui.engine.panel.BootUiPanels;
import io.github.jdubois.bootui.engine.safety.ApiTokenAuthenticator;
import io.github.jdubois.bootui.engine.sqltrace.SqlTraceRecorder;
import io.github.jdubois.bootui.engine.telemetry.TelemetryStore;
import io.github.jdubois.bootui.engine.transactions.TransactionRecorder;
import io.github.jdubois.bootui.engine.websocket.WebSocketActivityRecorder;
import io.github.jdubois.bootui.engine.websocket.WebSocketService;
import io.github.jdubois.bootui.engine.websocket.WebSocketSettings;
import io.github.jdubois.bootui.spi.LowFootprintSuspendable;
import io.github.jdubois.bootui.spi.ThreadKindClassifier;
import java.nio.file.Paths;
import java.util.Set;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.aot.AotDetector;
import org.springframework.beans.factory.ListableBeanFactory;
import org.springframework.beans.factory.ObjectProvider;
import org.springframework.beans.factory.config.BeanDefinition;
import org.springframework.beans.factory.config.BeanFactoryPostProcessor;
import org.springframework.beans.factory.support.BeanDefinitionRegistry;
import org.springframework.boot.actuate.audit.AuditEventRepository;
import org.springframework.boot.actuate.audit.InMemoryAuditEventRepository;
import org.springframework.boot.actuate.autoconfigure.web.exchanges.HttpExchangesProperties;
import org.springframework.boot.actuate.web.exchanges.HttpExchangeRepository;
import org.springframework.boot.autoconfigure.AutoConfiguration;
import org.springframework.boot.autoconfigure.AutoConfigurationPackages;
import org.springframework.boot.autoconfigure.AutoConfigureBefore;
import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.autoconfigure.condition.ConditionalOnWebApplication;
import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.boot.servlet.actuate.web.exchanges.HttpExchangesFilter;
import org.springframework.boot.servlet.filter.OrderedFilter;
import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationListener;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Conditional;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;
import org.springframework.context.annotation.ImportRuntimeHints;
import org.springframework.context.annotation.Lazy;
import org.springframework.core.Ordered;
import org.springframework.core.env.ConfigurableEnvironment;
import org.springframework.core.env.Environment;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;
import org.springframework.web.util.DisconnectedClientHelper;
import tools.jackson.databind.ObjectMapper;

/**
 * Main BootUI auto-configuration entry point.
 *
 * <p>Activates only when {@link BootUiActivationCondition} matches, when the app
 * is a servlet web application, and when Spring MVC is on the classpath.</p>
 */
@AutoConfiguration
@AutoConfigureBefore(
        name = {
            "org.springframework.boot.micrometer.tracing.opentelemetry.autoconfigure.OpenTelemetryTracingAutoConfiguration",
            "org.springframework.boot.actuate.autoconfigure.audit.AuditAutoConfiguration",
            "org.springframework.boot.actuate.autoconfigure.web.exchanges.HttpExchangesEndpointAutoConfiguration",
            "org.springframework.boot.servlet.autoconfigure.actuate.web.exchanges.ServletHttpExchangesAutoConfiguration"
        })
@Conditional(BootUiActivationCondition.class)
@ConditionalOnWebApplication(type = ConditionalOnWebApplication.Type.SERVLET)
@ConditionalOnClass(name = "org.springframework.web.servlet.DispatcherServlet")
@EnableConfigurationProperties(BootUiProperties.class)
@ImportRuntimeHints({BootUiRuntimeHints.class, SqlTraceRuntimeHints.class})
@Import({
    OverviewController.class,
    ActionBusyExceptionHandler.class,
    AdvisorViolationExceptionHandler.class,
    GitHubController.class,
    PanelsController.class,
    BeansController.class,
    ConditionsController.class,
    ConfigController.class,
    MappingsController.class,
    HealthController.class,
    LoggersController.class,
    StartupController.class,
    DataController.class,
    HibernateController.class,
    HibernateStatisticsController.class,
    FlywayController.class,
    LiquibaseController.class,
    DatabaseConnectionPoolsController.class,
    DatabaseAdvisorController.class,
    PostgresqlController.class,
    MySqlController.class,
    SpringCacheController.class,
    DevServicesController.class,
    VulnerabilitiesController.class,
    BootUiAutoConfiguration.HttpExchangeRepositoryConfiguration.class,
    BootUiAutoConfiguration.SecurityAuditRepositoryConfiguration.class,
    ScheduledController.class,
    FaultToleranceController.class,
    HttpProbeController.class,
    PentestingController.class,
    HeapDumpController.class,
    ArchitectureController.class,
    RestApiController.class,
    LogTailController.class,
    ExceptionsController.class,
    BootUiAutoConfiguration.ExceptionsConfiguration.class,
    BootUiAutoConfiguration.McpConfiguration.class,
    McpServerController.class,
    HttpExchangesController.class,
    ProfileDiffController.class,
    SpringSecurityController.class,
    SecurityController.class,
    SpringController.class,
    SecurityLogsController.class,
    LiveMemoryController.class,
    JvmTuningController.class,
    MetricsController.class,
    HttpSessionsController.class,
    DevToolsController.class,
    TracesController.class,
    AiController.class,
    OtlpReceiverController.class,
    CopilotController.class,
    ClaudeCodeController.class,
    GraalVmController.class,
    CracController.class,
    LiveActivityController.class,
    LiveServiceMapController.class,
    RuntimeInsightsController.class,
    JavaAgentController.class,
    CodeInventoryController.class,
    CodePathsController.class,
    SideEffectsController.class,
    EmailController.class,
    KafkaController.class,
    RabbitController.class,
    JmsController.class,
    SqlTraceController.class,
    TransactionsController.class,
    RestClientTraceController.class,
    BootUiAutoConfiguration.WebSocketConfiguration.class,
    ThreadDumpController.class,
    MemoryController.class,
    DismissedRulesController.class,
    BootUiIndexController.class,
    BootUiEngineConfiguration.class,
    BootUiOpenTelemetryConfiguration.class
})
public class BootUiAutoConfiguration {

    private static final Logger log = LoggerFactory.getLogger(BootUiAutoConfiguration.class);

    private static final Set<String> LAZY_CONTROLLER_CLASS_NAMES = Set.of(
            AiController.class.getName(),
            ArchitectureController.class.getName(),
            RestApiController.class.getName(),
            BeansController.class.getName(),
            BootUiIndexController.class.getName(),
            HibernateController.class.getName(),
            HibernateStatisticsController.class.getName(),
            SpringCacheController.class.getName(),
            ClaudeCodeController.class.getName(),
            ConditionsController.class.getName(),
            ConfigController.class.getName(),
            CopilotController.class.getName(),
            DataController.class.getName(),
            FlywayController.class.getName(),
            LiquibaseController.class.getName(),
            VulnerabilitiesController.class.getName(),
            DevToolsController.class.getName(),
            GitHubController.class.getName(),
            GraalVmController.class.getName(),
            CracController.class.getName(),
            LiveActivityController.class.getName(),
            LiveServiceMapController.class.getName(),
            RuntimeInsightsController.class.getName(),
            JavaAgentController.class.getName(),
            CodeInventoryController.class.getName(),
            CodePathsController.class.getName(),
            SideEffectsController.class.getName(),
            EmailController.class.getName(),
            KafkaController.class.getName(),
            RabbitController.class.getName(),
            JmsController.class.getName(),
            SqlTraceController.class.getName(),
            TransactionsController.class.getName(),
            RestClientTraceController.class.getName(),
            WebSocketController.class.getName(),
            HealthController.class.getName(),
            DatabaseConnectionPoolsController.class.getName(),
            HttpExchangesController.class.getName(),
            HttpSessionsController.class.getName(),
            HttpProbeController.class.getName(),
            HeapDumpController.class.getName(),
            LoggersController.class.getName(),
            MappingsController.class.getName(),
            LiveMemoryController.class.getName(),
            JvmTuningController.class.getName(),
            MetricsController.class.getName(),
            OtlpReceiverController.class.getName(),
            OverviewController.class.getName(),
            PanelsController.class.getName(),
            PentestingController.class.getName(),
            ProfileDiffController.class.getName(),
            ScheduledController.class.getName(),
            FaultToleranceController.class.getName(),
            SecurityLogsController.class.getName(),
            SecurityController.class.getName(),
            SpringController.class.getName(),
            SpringSecurityController.class.getName(),
            StartupController.class.getName(),
            TracesController.class.getName(),
            ExceptionsController.class.getName(),
            ThreadDumpController.class.getName(),
            MemoryController.class.getName(),
            McpServerController.class.getName(),
            DismissedRulesController.class.getName());

    private static final Set<String> LAZY_BEAN_NAMES =
            Set.of("bootUiConfigOverrideService", "bootUiDevToolsBridge", "bootUiOtlpSpanDecoder");

    @Bean
    static BeanFactoryPostProcessor bootUiLazyBeanPostProcessor(ConfigurableEnvironment environment) {
        return beanFactory -> {
            BootUiPathPropertySource.apply(environment);
            for (String beanName : beanFactory.getBeanDefinitionNames()) {
                BeanDefinition beanDefinition = beanFactory.getBeanDefinition(beanName);
                String beanClassName = beanDefinition.getBeanClassName();
                if (LAZY_BEAN_NAMES.contains(beanName)
                        || (beanClassName != null && LAZY_CONTROLLER_CLASS_NAMES.contains(beanClassName))) {
                    beanDefinition.setLazyInit(true);
                }
            }
        };
    }

    @Configuration(proxyBeanMethods = false)
    @ConditionalOnClass(name = "org.springframework.boot.actuate.web.exchanges.HttpExchangeRepository")
    @ConditionalOnProperty(prefix = "bootui.panels.http-exchanges", name = "enabled", matchIfMissing = true)
    @EnableConfigurationProperties(HttpExchangesProperties.class)
    static class HttpExchangeRepositoryConfiguration {

        private static final int HTTP_EXCHANGES_FILTER_ORDER = OrderedFilter.REQUEST_WRAPPER_FILTER_MAX_ORDER - 101;

        private static final String BOOTUI_HTTP_EXCHANGE_REPOSITORY_BEAN = "bootUiHttpExchangeRepository";

        private static final String BOOTUI_HTTP_EXCHANGES_FILTER_BEAN = "bootUiHttpExchangesFilter";

        /**
         * BootUI's failure-preserving repository. When the application registers its own
         * {@link HttpExchangesFilter}, BootUI keeps its back-off: the repository is created without a reserved
         * share and reports its retention as application-managed.
         */
        @Bean
        @ConditionalOnMissingBean(HttpExchangeRepository.class)
        HttpExchangeRepository bootUiHttpExchangeRepository(
                BootUiProperties properties, Environment environment, ListableBeanFactory beanFactory) {
            return new BootUiHttpExchangeRepository(
                    properties.getHttpExchanges().getMaxExchanges(),
                    properties.getHttpExchanges().getReservedSharePercent(),
                    ExchangeSlowThreshold.resolve(properties, environment),
                    BootUiHttpExchangeRepository.isRecordedByApplication(
                            beanFactory, HttpExchangesFilter.class, BOOTUI_HTTP_EXCHANGES_FILTER_BEAN));
        }

        /**
         * Drops BootUI's fallback repository when the application also contributes its own
         * {@link HttpExchangeRepository}.
         *
         * <p>BootUI runs {@code @AutoConfigureBefore} the standard HTTP exchange auto-configurations,
         * so the {@link ConditionalOnMissingBean} guard on {@link #bootUiHttpExchangeRepository} cannot
         * detect a repository contributed by a configuration ordered after BootUI (such as the
         * application's own auto-configuration). That would otherwise leave two repositories in the
         * context and break single-bean injection &mdash; both BootUI's recording filter and Spring
         * Boot's own {@code httpExchangesEndpoint}. Reconciling as a {@link BeanFactoryPostProcessor}
         * runs after every bean definition has been registered, regardless of ordering, and before any
         * bean is instantiated, so the application's repository always wins.</p>
         */
        @Bean
        static BeanFactoryPostProcessor bootUiHttpExchangeRepositoryDeduplicator() {
            return beanFactory -> {
                if (!(beanFactory instanceof BeanDefinitionRegistry registry)
                        || !registry.containsBeanDefinition(BOOTUI_HTTP_EXCHANGE_REPOSITORY_BEAN)) {
                    return;
                }
                for (String name : beanFactory.getBeanNamesForType(HttpExchangeRepository.class, true, false)) {
                    if (!BOOTUI_HTTP_EXCHANGE_REPOSITORY_BEAN.equals(name)) {
                        registry.removeBeanDefinition(BOOTUI_HTTP_EXCHANGE_REPOSITORY_BEAN);
                        return;
                    }
                }
            };
        }

        @Bean(BOOTUI_HTTP_EXCHANGES_FILTER_BEAN)
        @ConditionalOnMissingBean(HttpExchangesFilter.class)
        @ConditionalOnProperty(
                prefix = "management.httpexchanges.recording",
                name = "enabled",
                havingValue = "true",
                matchIfMissing = true)
        HttpExchangesFilter bootUiHttpExchangesFilter(
                HttpExchangeRepository repository,
                HttpExchangesProperties properties,
                BootUiProperties bootUiProperties,
                ObjectProvider<BootUiSelfDataFilter> selfDataFilter) {
            HttpExchangesFilter filter = new BootUiHttpExchangesFilter(
                    repository,
                    properties.getRecording().getInclude(),
                    bootUiProperties,
                    selfDataFilter.getIfAvailable(() -> new BootUiSelfDataFilter(bootUiProperties)));
            filter.setOrder(HTTP_EXCHANGES_FILTER_ORDER);
            return filter;
        }
    }

    @Configuration(proxyBeanMethods = false)
    @ConditionalOnClass(
            name = {
                "org.springframework.boot.actuate.audit.AuditEventRepository",
                "org.springframework.security.authentication.event.AbstractAuthenticationEvent"
            })
    @ConditionalOnProperty(name = "management.auditevents.enabled", havingValue = "true", matchIfMissing = true)
    @ConditionalOnProperty(prefix = "bootui.panels.security-logs", name = "enabled", matchIfMissing = true)
    static class SecurityAuditRepositoryConfiguration {

        @Bean
        @ConditionalOnMissingBean(AuditEventRepository.class)
        AuditEventRepository bootUiAuditEventRepository() {
            return new InMemoryAuditEventRepository();
        }
    }

    /**
     * The servlet WebSockets panel backend, wired only when {@code spring-websocket} and
     * {@code spring-messaging} are both on the classpath. Every WebSocket type is referenced from inside
     * this {@code @ConditionalOnClass}-gated nested configuration (never from the always-active root
     * config), so an application without {@code spring-boot-starter-websocket} never links them.
     *
     * <p>The capture configurer is a plain {@code WebSocketMessageBrokerConfigurer}: it only contributes
     * when the application itself enabled STOMP, it adds one decorator factory and one interceptor per
     * client channel, and it changes no broker, transport, or destination configuration. When
     * {@code bootui.websockets.enabled=false} the configurer is not registered at all, so BootUI
     * contributes nothing to the application's WebSocket pipeline.</p>
     */
    @Configuration(proxyBeanMethods = false)
    @ConditionalOnClass(
            name = {
                "org.springframework.web.socket.server.support.WebSocketHandlerMapping",
                "org.springframework.messaging.simp.annotation.support.SimpAnnotationMethodMessageHandler"
            })
    @ConditionalOnProperty(prefix = "bootui.panels.websockets", name = "enabled", matchIfMissing = true)
    static class WebSocketConfiguration {

        @Bean
        @ConditionalOnMissingBean
        SpringWebSocketMetadataProvider bootUiSpringWebSocketMetadataProvider(ApplicationContext context) {
            return new SpringWebSocketMetadataProvider(context);
        }

        @Bean
        @ConditionalOnMissingBean
        BootUiWebSocketSessionRegistry bootUiWebSocketSessionRegistry(WebSocketSettings settings) {
            return new BootUiWebSocketSessionRegistry(settings);
        }

        @Bean
        @ConditionalOnProperty(prefix = "bootui.websockets", name = "enabled", matchIfMissing = true)
        BootUiWebSocketCaptureConfigurer bootUiWebSocketCaptureConfigurer(
                WebSocketActivityRecorder recorder,
                BootUiWebSocketSessionRegistry registry,
                SpringWebSocketMetadataProvider metadataProvider) {
            return new BootUiWebSocketCaptureConfigurer(recorder, registry, metadataProvider);
        }

        @Bean
        @Lazy
        @ConditionalOnMissingBean
        WebSocketService bootUiWebSocketService(
                SpringWebSocketMetadataProvider metadataProvider,
                BootUiWebSocketSessionRegistry registry,
                WebSocketActivityRecorder recorder,
                WebSocketSettings settings,
                BootUiExposure exposure) {
            return new WebSocketService(metadataProvider, registry, recorder, settings, exposure);
        }

        @Bean
        @Lazy
        WebSocketController bootUiWebSocketController(
                ObjectProvider<WebSocketService> serviceProvider,
                ObjectProvider<WebSocketActivityRecorder> recorderProvider) {
            return new WebSocketController(serviceProvider, recorderProvider);
        }
    }

    @Configuration(proxyBeanMethods = false)
    @ConditionalOnProperty(prefix = "bootui.panels.exceptions", name = "enabled", matchIfMissing = true)
    static class ExceptionsConfiguration {

        @Bean
        ExceptionStore bootUiExceptionStore(BootUiProperties properties, ApplicationContext applicationContext) {
            BootUiProperties.Exceptions config = properties.getExceptions();
            ExceptionStore store = new ExceptionStore(
                    config.getMaxGroups(),
                    config.getMaxOccurrencesPerGroup(),
                    config.getMaxStackFrames(),
                    DisconnectedClientHelper::isClientDisconnectedException);
            try {
                if (AutoConfigurationPackages.has(applicationContext)) {
                    store.setApplicationPackages(AutoConfigurationPackages.get(applicationContext));
                }
            } catch (RuntimeException ex) {
                log.debug("BootUI could not resolve application base packages for exception capture", ex);
            }
            return store;
        }

        @Bean
        BootUiExceptionHandlerResolver bootUiExceptionHandlerResolver(ExceptionStore store) {
            return new BootUiExceptionHandlerResolver(store);
        }

        @Configuration(proxyBeanMethods = false)
        @ConditionalOnClass(name = "ch.qos.logback.classic.LoggerContext")
        static class LogbackExceptionCaptureConfiguration {

            @Bean(destroyMethod = "uninstall")
            BootUiExceptionLogAppender bootUiExceptionLogAppender(ExceptionStore store) {
                return BootUiExceptionLogAppender.install(store);
            }
        }
    }

    /**
     * Registers the local-only MCP server beans. The beans are always registered while BootUI is
     * active, but the server only serves requests while {@link McpServerState} is enabled. The live
     * state is initialized from {@code bootui.mcp.enabled} (fail closed: {@code OFF}/{@code AUTO}
     * start disabled) and can be toggled at runtime from the MCP Server panel. BootUI's activation
     * condition keeps it confined to dev contexts, and the endpoint lives under {@code /bootui/api}
     * so it inherits the loopback/Host/cross-site safety filters. Tools are thin adapters over the
     * existing BootUI controllers, so masking and per-panel toggles still apply.
     */
    @Configuration(proxyBeanMethods = false)
    static class McpConfiguration {

        @Bean
        McpServerState bootUiMcpServerState(BootUiProperties properties) {
            return new McpServerState(properties.getMcp().getEnabled());
        }

        @Bean
        @Lazy
        BootUiMcpTools bootUiMcpTools(
                ObjectProvider<OverviewController> overview,
                ObjectProvider<HealthController> health,
                ObjectProvider<ConfigController> config,
                ObjectProvider<BeansController> beans,
                ObjectProvider<MappingsController> mappings,
                ObjectProvider<ExceptionsController> exceptions,
                ObjectProvider<LiveActivityController> liveActivity,
                ObjectProvider<SecurityLogsController> securityLogs,
                ObjectProvider<SqlTraceController> sqlTrace,
                ObjectProvider<TransactionsController> transactions,
                ObjectProvider<TracesController> traces,
                ObjectProvider<LogTailController> logTail,
                ObjectProvider<HttpExchangesController> httpExchanges,
                ObjectProvider<ArchitectureController> architecture,
                ObjectProvider<SpringController> spring,
                ObjectProvider<HibernateController> hibernate,
                ObjectProvider<MemoryController> memory,
                ObjectProvider<SecurityController> security,
                ObjectProvider<PentestingController> pentesting,
                ObjectProvider<RestApiController> restApi,
                ObjectProvider<GraalVmController> graalvm,
                ObjectProvider<CracController> crac,
                ObjectProvider<DatabaseAdvisorController> databaseAdvisor,
                ObjectProvider<PostgresqlController> postgresql,
                ObjectProvider<MySqlController> mysql,
                ObjectProvider<VulnerabilitiesController> vulnerabilities,
                ObjectProvider<LoggersController> loggers,
                ObjectProvider<ConditionsController> conditions,
                ObjectProvider<ScheduledController> scheduled,
                ObjectProvider<FaultToleranceController> faultTolerance,
                ObjectProvider<SpringCacheController> cache,
                ObjectProvider<DatabaseConnectionPoolsController> connectionPools,
                ObjectProvider<RuntimeInsightsController> runtimeInsights,
                ObjectProvider<JavaAgentController> javaAgent,
                ObjectProvider<CodeInventoryController> codeInventory,
                ObjectProvider<CodePathsController> codePaths,
                ObjectProvider<SideEffectsController> sideEffects) {
            return new BootUiMcpTools(
                    overview,
                    health,
                    config,
                    beans,
                    mappings,
                    exceptions,
                    liveActivity,
                    securityLogs,
                    sqlTrace,
                    transactions,
                    traces,
                    logTail,
                    httpExchanges,
                    architecture,
                    spring,
                    hibernate,
                    memory,
                    security,
                    pentesting,
                    restApi,
                    graalvm,
                    crac,
                    databaseAdvisor,
                    postgresql,
                    mysql,
                    vulnerabilities,
                    loggers,
                    conditions,
                    scheduled,
                    faultTolerance,
                    cache,
                    connectionPools,
                    runtimeInsights,
                    javaAgent,
                    codeInventory,
                    codePaths,
                    sideEffects);
        }

        @Bean
        @Lazy
        BootUiMcpService bootUiMcpService(
                BootUiMcpTools tools, BootUiProperties properties, ObjectProvider<ObjectMapper> objectMapper) {
            String version = BootUiAutoConfiguration.class.getPackage().getImplementationVersion();
            return new BootUiMcpService(tools, properties, objectMapper.getIfAvailable(ObjectMapper::new), version);
        }

        @Bean
        @Lazy
        BootUiMcpController bootUiMcpController(
                BootUiMcpService service, McpServerState state, BootUiProperties properties) {
            return new BootUiMcpController(service, state, properties);
        }

        /**
         * The command-line facade over the same tool registry. It gets its own dispatcher, and therefore its
         * own call counters and concurrency budget, so terminal traffic never shows up as MCP agent activity
         * in the MCP Server panel.
         */
        @Bean
        @Lazy
        CliService bootUiCliService(BootUiMcpTools tools, BootUiProperties properties) {
            String version = BootUiAutoConfiguration.class.getPackage().getImplementationVersion();
            return BootUiCliServiceFactory.create(
                    tools::tools,
                    tools::panelUnavailableReason,
                    new SpringMcpPanelPolicy(properties),
                    properties,
                    version);
        }

        @Bean
        @Lazy
        BootUiCliController bootUiCliController(CliService service) {
            return new BootUiCliController(service);
        }
    }

    @Bean
    public BootUiActivation bootUiActivation(Environment environment) {
        BootUiActivation activation =
                BootUiActivationCondition.resolve(environment, getClass().getClassLoader());
        if (!activation.enabled() && AotDetector.useGeneratedArtifacts()) {
            // In a native image (or any AOT-generated context) BootUiAutoConfiguration's activation
            // condition is frozen from build time: this bean only exists because the condition
            // matched then. The live runtime environment may no longer match (for example the
            // build-time 'dev' profile is not active at runtime), so resolve() would mis-report
            // BootUI as disabled even though it is wired into the image and serving. Trust the frozen
            // build-time decision so the Overview panel and startup log reflect reality. A runtime
            // bootui.enabled=OFF cannot remove the baked-in beans, so it does not change this.
            activation = new BootUiActivation(true, "Enabled at build time (AOT/native image)", activation.warnings());
        }
        log.info("BootUI activation: {}", activation.reason());
        for (String warning : activation.warnings()) {
            log.warn("BootUI activation warning: {}", warning);
        }
        return activation;
    }

    @Bean
    public DismissedRulesStore bootUiDismissedRulesStore(BootUiProperties properties) {
        String overridesFile = properties.getOverridesFile();
        java.nio.file.Path parent = (overridesFile != null && !overridesFile.isBlank())
                ? Paths.get(overridesFile).getParent()
                : null;
        String dir = (parent != null) ? parent.toString() : ".bootui";
        return new DismissedRulesStore(Paths.get(dir, "boot-ui.yml"));
    }

    @Bean
    public ConfigOverrideService bootUiConfigOverrideService(
            ConfigurableEnvironment environment, BootUiProperties properties, BootUiExposure exposure) {
        return new ConfigOverrideService(environment, properties, exposure);
    }

    @Bean
    public BootUiExposure bootUiExposure(Environment environment, BootUiProperties properties) {
        return new BootUiExposure(environment, properties);
    }

    @Bean
    public DevToolsBridge bootUiDevToolsBridge(ApplicationContext applicationContext) {
        return new DefaultDevToolsBridge(applicationContext);
    }

    @Bean
    public SecurityHeadersFilter bootUiSecurityHeadersFilter(BootUiProperties properties) {
        return new SecurityHeadersFilter(properties);
    }

    @Bean
    public LocalhostOnlyFilter bootUiLocalhostOnlyFilter(BootUiProperties properties) {
        // The filter constructs its own (framework-neutral, engine-owned) ContainerGatewayDetector so it
        // can auto-trust the container default gateway per bootui.trust-container-gateway.
        return new LocalhostOnlyFilter(properties);
    }

    @Bean
    public ApiTokenAuthenticator bootUiApiTokenAuthenticator(BootUiProperties properties) {
        return new ApiTokenAuthenticator(properties.getAuthentication().getToken());
    }

    @Bean
    public ApiAuthenticationFilter bootUiApiAuthenticationFilter(
            BootUiProperties properties, ApiTokenAuthenticator authenticator, LocalhostOnlyFilter localhostOnlyFilter) {
        return new ApiAuthenticationFilter(properties, authenticator, localhostOnlyFilter);
    }

    @Bean
    public BootUiStaticResourceConfigurer bootUiStaticResourceConfigurer(
            Environment environment, BootUiProperties properties) {
        return new BootUiStaticResourceConfigurer(environment, properties);
    }

    @Bean
    public BootUiJsonWebMvcConfigurer bootUiJsonWebMvcConfigurer(BootUiProperties properties) {
        return new BootUiJsonWebMvcConfigurer(properties);
    }

    @Bean
    public PanelAccessFilter bootUiPanelAccessFilter(
            BootUiProperties properties, ObjectProvider<RuntimeJournal> journal) {
        PanelAccessFilter filter = new PanelAccessFilter(properties);
        filter.setJournal(journal::getIfAvailable);
        return filter;
    }

    @Bean
    public TelemetryStore bootUiTelemetryStore(BootUiProperties properties) {
        return new TelemetryStore(new SpringTelemetrySettings(properties));
    }

    /**
     * Bridges the framework-neutral {@link TelemetryStore} to BootUI's idle-reclaim mechanism. The
     * store no longer implements {@link IdleReclaimable} (it stays engine-neutral), so this thin
     * delegate lets {@link ConsoleActivityTracker} suspend and resume span capture while the console
     * is idle, exactly as before the engine extraction.
     */
    @Bean
    public IdleReclaimable bootUiTelemetryStoreIdleReclaimable(TelemetryStore store) {
        return new IdleReclaimable() {
            @Override
            public void suspendForIdle() {
                store.suspendForIdle();
            }

            @Override
            public void resumeFromIdle() {
                store.resumeFromIdle();
            }
        };
    }

    @Bean
    public BootUiSelfDataFilter bootUiSelfDataFilter(BootUiProperties properties) {
        return new BootUiSelfDataFilter(properties);
    }

    @Bean
    public RequestCorrelationRegistry bootUiRequestCorrelationRegistry(BootUiProperties properties) {
        // This registry feeds exact thread-based correlation, not the display list, so it is sized well
        // above the page cap: a single page load records many static-resource requests, and undersizing
        // it would evict an API request's correlation before the feed or profiler reads it back.
        int capacity = Math.max(properties.getActivity().getMaxEntries() * 4, 512);
        return new RequestCorrelationRegistry(capacity);
    }

    @Bean
    public HttpExchangeTraceRegistry bootUiHttpExchangeTraceRegistry(BootUiProperties properties) {
        return HttpExchangeTraceRegistry.forExchangeRepository(
                properties.getHttpExchanges().getMaxExchanges());
    }

    @Bean
    public SecurityEventCorrelationRegistry bootUiSecurityEventCorrelationRegistry(BootUiProperties properties) {
        return new SecurityEventCorrelationRegistry(properties.getActivity().getMaxEntries());
    }

    /** This stack's classifier of the thread each operation starts on ({@code docs/PLAN-v2.md} §5.1). */
    @Bean
    public ThreadKindClassifier bootUiThreadKindClassifier() {
        return new ServletThreadKinds();
    }

    @Bean
    public SqlTraceRecorder bootUiSqlTraceRecorder(
            BootUiProperties properties, ThreadKindClassifier threadKinds, RequestPhases phases) {
        BootUiProperties.SqlTrace sqlTrace = properties.getSqlTrace();
        boolean enabled = sqlTrace.isEnabled() && properties.isPanelEnabled(BootUiPanels.SQL_TRACE);
        SqlTraceRecorder recorder = new SqlTraceRecorder(
                enabled,
                sqlTrace.isRecording(),
                sqlTrace.isCaptureParameters(),
                sqlTrace.isCaptureCallSite(),
                sqlTrace.getMaxEntries(),
                sqlTrace.getSlowQueryThresholdMillis(),
                sqlTrace.getMaxSqlLength(),
                sqlTrace.getMaxParameterLength(),
                sqlTrace.getNPlusOneThreshold(),
                sqlTrace.getReservedSharePercent());
        recorder.setThreadKindClassifier(threadKinds);
        recorder.setRequestPhases(phases);
        return recorder;
    }

    /**
     * Bridges the now-neutral {@link SqlTraceRecorder} (engine, implements {@code spi.IdleReclaimable})
     * to BootUI's Spring idle-reclaim mechanism so {@link ConsoleActivityTracker} keeps suspending and
     * resuming SQL capture while the console is idle, exactly as before the engine extraction.
     */
    @Bean
    public IdleReclaimable bootUiSqlTraceRecorderIdleReclaimable(SqlTraceRecorder recorder) {
        return new IdleReclaimable() {
            @Override
            public void suspendForIdle() {
                recorder.suspendForIdle();
            }

            @Override
            public void resumeFromIdle() {
                recorder.resumeFromIdle();
            }
        };
    }

    @Bean
    static SqlTraceDataSourceBeanPostProcessor bootUiSqlTraceDataSourceBeanPostProcessor(
            org.springframework.beans.factory.ObjectProvider<SqlTraceRecorder> recorderProvider) {
        return new SqlTraceDataSourceBeanPostProcessor(recorderProvider);
    }

    /**
     * Correlates the Transactions panel to SQL Trace's already-captured executions (see {@link
     * TransactionRecorder}'s class Javadoc), so it must be created after {@code
     * bootUiSqlTraceRecorder}. Depending on the {@code SqlTraceRecorder} bean rather than injecting it
     * as an {@code ObjectProvider} is deliberate: both beans are always registered by this
     * auto-configuration, so there is no "may be absent" case to defer.
     */
    @Bean
    public TransactionRecorder bootUiTransactionRecorder(
            BootUiProperties properties, SqlTraceRecorder sqlTraceRecorder) {
        BootUiProperties.Transactions transactions = properties.getTransactions();
        boolean enabled = transactions.isEnabled() && properties.isPanelEnabled(BootUiPanels.TRANSACTIONS);
        return new TransactionRecorder(
                enabled,
                transactions.isRecording(),
                transactions.getMaxEntries(),
                transactions.getSlowTransactionThresholdMillis(),
                transactions.getConnectionHoldThresholdMillis(),
                sqlTraceRecorder);
    }

    /**
     * Bridges the framework-neutral {@link TransactionRecorder} (implements {@code
     * spi.IdleReclaimable}) to BootUI's Spring idle-reclaim mechanism, exactly as {@code
     * bootUiSqlTraceRecorderIdleReclaimable} does for SQL Trace.
     */
    @Bean
    public IdleReclaimable bootUiTransactionRecorderIdleReclaimable(TransactionRecorder recorder) {
        return new IdleReclaimable() {
            @Override
            public void suspendForIdle() {
                recorder.suspendForIdle();
            }

            @Override
            public void resumeFromIdle() {
                recorder.resumeFromIdle();
            }
        };
    }

    @Bean
    @ConditionalOnProperty(prefix = "bootui.transactions", name = "enabled", matchIfMissing = true)
    @ConditionalOnProperty(prefix = "bootui.panels.transactions", name = "enabled", matchIfMissing = true)
    public BootUiTransactionExecutionListener bootUiTransactionExecutionListener(TransactionRecorder recorder) {
        return new BootUiTransactionExecutionListener(recorder);
    }

    @Bean
    @ConditionalOnProperty(prefix = "bootui.transactions", name = "enabled", matchIfMissing = true)
    @ConditionalOnProperty(prefix = "bootui.panels.transactions", name = "enabled", matchIfMissing = true)
    public BootUiTransactionManagerListenerRegistrar bootUiTransactionManagerListenerRegistrar(
            org.springframework.beans.factory.ObjectProvider<
                            org.springframework.transaction.ConfigurableTransactionManager>
                    transactionManagers,
            BootUiTransactionExecutionListener bootUiTransactionExecutionListener) {
        return new BootUiTransactionManagerListenerRegistrar(transactionManagers, bootUiTransactionExecutionListener);
    }

    /**
     * Wraps every {@link org.springframework.mail.javamail.JavaMailSender} bean so outgoing email is
     * captured for the Email Viewer panel. Guarded by {@code @ConditionalOnClass} (rather than being
     * unconditional like the SQL-trace post-processor above) because {@code JavaMailSender} comes from
     * the optional {@code spring-boot-starter-mail} dependency, which a host application may not have
     * on its classpath.
     */
    @Bean
    @org.springframework.boot.autoconfigure.condition.ConditionalOnClass(
            name = "org.springframework.mail.javamail.JavaMailSender")
    static BootUiMailSenderBeanPostProcessor bootUiMailSenderBeanPostProcessor(
            org.springframework.beans.factory.ObjectProvider<io.github.jdubois.bootui.engine.email.EmailCaptureService>
                    captureServiceProvider) {
        return new BootUiMailSenderBeanPostProcessor(captureServiceProvider);
    }

    @Bean
    public OtlpSpanDecoder bootUiOtlpSpanDecoder(BootUiProperties properties) {
        return new OtlpSpanDecoder(properties.getTelemetry());
    }

    @Bean(destroyMethod = "stop")
    @Lazy
    public io.github.jdubois.bootui.autoconfigure.web.CopilotSessionStore bootUiCopilotSessionStore(
            BootUiProperties properties) {
        io.github.jdubois.bootui.autoconfigure.web.CopilotSessionStore store =
                new io.github.jdubois.bootui.autoconfigure.web.CopilotSessionStore(properties.getCopilot());
        if (properties.getCopilot().getEnabled() != BootUiProperties.Mode.OFF) {
            store.start();
        }
        return store;
    }

    @Bean(destroyMethod = "stop")
    @Lazy
    public io.github.jdubois.bootui.autoconfigure.web.ClaudeCodeSessionStore bootUiClaudeCodeSessionStore(
            BootUiProperties properties) {
        io.github.jdubois.bootui.autoconfigure.web.ClaudeCodeSessionStore store =
                new io.github.jdubois.bootui.autoconfigure.web.ClaudeCodeSessionStore(properties.getClaudeCode());
        if (properties.getClaudeCode().getEnabled() != BootUiProperties.Mode.OFF) {
            store.start();
        }
        return store;
    }

    @Bean
    public FilterRegistrationBean<LegacyBootUiPathFilter> bootUiLegacyPathFilterRegistration(
            BootUiProperties properties) {
        FilterRegistrationBean<LegacyBootUiPathFilter> registration =
                new FilterRegistrationBean<>(new LegacyBootUiPathFilter(properties));
        registration.addUrlPatterns("/bootui/*");
        registration.setOrder(Integer.MIN_VALUE);
        registration.setName("bootUiLegacyPathFilter");
        return registration;
    }

    @Bean
    public FilterRegistrationBean<SecurityHeadersFilter> bootUiSecurityHeadersFilterRegistration(
            SecurityHeadersFilter filter, BootUiProperties properties) {
        FilterRegistrationBean<SecurityHeadersFilter> registration = new FilterRegistrationBean<>(filter);
        registration.addUrlPatterns(properties.getPath() + "/*", properties.getApiPath() + "/*");
        registration.setOrder(Integer.MIN_VALUE);
        registration.setName("bootUiSecurityHeadersFilter");
        return registration;
    }

    @Bean
    public FilterRegistrationBean<LocalhostOnlyFilter> bootUiLocalhostOnlyFilterRegistration(
            LocalhostOnlyFilter filter, BootUiProperties properties) {
        FilterRegistrationBean<LocalhostOnlyFilter> registration = new FilterRegistrationBean<>(filter);
        registration.addUrlPatterns(properties.getPath() + "/*", properties.getApiPath() + "/*");
        registration.setOrder(Integer.MIN_VALUE + 1);
        registration.setName("bootUiLocalhostOnlyFilter");
        return registration;
    }

    @Bean
    public FilterRegistrationBean<PanelAccessFilter> bootUiPanelAccessFilterRegistration(
            PanelAccessFilter filter, BootUiProperties properties) {
        FilterRegistrationBean<PanelAccessFilter> registration = new FilterRegistrationBean<>(filter);
        registration.addUrlPatterns(properties.getApiPath() + "/*");
        registration.setOrder(Integer.MIN_VALUE + 3);
        registration.setName("bootUiPanelAccessFilter");
        return registration;
    }

    @Bean
    public FilterRegistrationBean<ApiAuthenticationFilter> bootUiApiAuthenticationFilterRegistration(
            ApiAuthenticationFilter filter, BootUiProperties properties) {
        FilterRegistrationBean<ApiAuthenticationFilter> registration = new FilterRegistrationBean<>(filter);
        registration.addUrlPatterns(properties.getApiPath() + "/*");
        registration.setOrder(Integer.MIN_VALUE + 2);
        registration.setName("bootUiApiAuthenticationFilter");
        return registration;
    }

    @Bean(destroyMethod = "close")
    @ConditionalOnProperty(prefix = "bootui.free-on-idle", name = "enabled", matchIfMissing = true)
    public ConsoleActivityTracker bootUiConsoleActivityTracker(
            BootUiProperties properties,
            ObjectProvider<IdleReclaimable> buffers,
            ObjectProvider<LowFootprintService> lowFootprint) {
        return new ConsoleActivityTracker(
                properties.getFreeOnIdle().getTimeout(), buffers.orderedStream().toList(), () -> {
                    LowFootprintService service = lowFootprint.getIfAvailable();
                    return service != null && service.active();
                });
    }

    /**
     * Low-footprint mode's handle on the Spring-side idle-reclaimable buffers (request and security correlation
     * windows, SQL and trace capture bridges), which the engine cannot see: it suspends them like an idle console
     * would and resumes them when the mode is turned off.
     */
    @Bean
    public LowFootprintSuspendable bootUiIdleBuffersLowFootprint(ObjectProvider<IdleReclaimable> buffers) {
        return new IdleBuffersLowFootprint(buffers);
    }

    @Bean
    @ConditionalOnProperty(prefix = "bootui.free-on-idle", name = "enabled", matchIfMissing = true)
    public FilterRegistrationBean<ConsoleActivityFilter> bootUiConsoleActivityFilterRegistration(
            ConsoleActivityTracker tracker, BootUiProperties properties) {
        FilterRegistrationBean<ConsoleActivityFilter> registration =
                new FilterRegistrationBean<>(new ConsoleActivityFilter(properties, tracker));
        registration.addUrlPatterns(properties.getPath() + "/*", properties.getApiPath() + "/*");
        registration.setOrder(Integer.MIN_VALUE + 4);
        registration.setName("bootUiConsoleActivityFilter");
        return registration;
    }

    @Bean
    public RequestPhaseResponseBodyAdvice bootUiRequestPhaseResponseBodyAdvice(RequestPhases phases) {
        return new RequestPhaseResponseBodyAdvice(phases);
    }

    @Bean
    public WebMvcConfigurer bootUiRequestPhaseWebMvcConfigurer(RequestPhases phases) {
        RequestPhaseInterceptor interceptor = new RequestPhaseInterceptor(phases);
        return new WebMvcConfigurer() {
            @Override
            public void addInterceptors(InterceptorRegistry registry) {
                registry.addInterceptor(interceptor).order(Ordered.HIGHEST_PRECEDENCE);
            }
        };
    }

    @Bean
    public FilterRegistrationBean<RequestCorrelationFilter> bootUiRequestCorrelationFilterRegistration(
            RequestCorrelationRegistry registry,
            HttpExchangeTraceRegistry traceRegistry,
            BootUiProperties properties,
            Environment environment,
            RequestPhases phases,
            RuntimeJournal journal) {
        RequestCorrelationFilter filter = new RequestCorrelationFilter(
                registry,
                traceRegistry,
                properties.getPath(),
                properties.getApiPath(),
                ExchangeSlowThreshold.resolve(properties, environment),
                phases);
        filter.setRuntimeEventSink(journal);
        // A Spring MVC request's scope is its whole handling on its pooled worker: the BootUI agent's thread-locals
        // sensor scans there (docs/PLAN-v2.md §5.16, M5-5f).
        AgentThreadLocals.configure(true);
        FilterRegistrationBean<RequestCorrelationFilter> registration = new FilterRegistrationBean<>(filter);
        registration.addUrlPatterns("/*");
        registration.setOrder(org.springframework.core.Ordered.HIGHEST_PRECEDENCE + 100);
        registration.setName("bootUiRequestCorrelationFilter");
        return registration;
    }

    @Bean
    public ApplicationListener<ApplicationReadyEvent> bootUiStartupBanner(
            BootUiProperties properties, Environment environment, ApiTokenAuthenticator authenticator) {
        return event -> {
            properties.getPanels().keySet().stream()
                    .filter(panelId -> !BootUiPanels.ids().contains(panelId))
                    .forEach(panelId -> log.warn(
                            "Unknown BootUI panel id '{}' configured under bootui.panels; known ids are {}",
                            panelId,
                            BootUiPanels.ids()));
            if (!properties.isShowBanner()) {
                logGeneratedTokenIfNeeded(properties, authenticator);
                return;
            }
            log.info("BootUI is available at {}", buildStartupUrl(environment, properties));
            logGeneratedTokenIfNeeded(properties, authenticator);
        };
    }

    private static void logGeneratedTokenIfNeeded(BootUiProperties properties, ApiTokenAuthenticator authenticator) {
        if (authenticator.generated() && remoteAccessConfigured(properties)) {
            log.info("BootUI bearer token for non-local API access: {}", authenticator.token());
        }
    }

    private static boolean remoteAccessConfigured(BootUiProperties properties) {
        return ApiTokenAuthenticator.remoteAccessConfigured(
                properties.isAllowNonLocalhost(),
                properties.getTrustedProxies() != null && properties.getTrustedProxies().length > 0,
                properties.getTrustContainerGateway() != BootUiProperties.Mode.OFF);
    }

    static String buildStartupUrl(Environment environment, BootUiProperties properties) {
        boolean sslEnabled = environment.getProperty("server.ssl.enabled", Boolean.class, false);
        String scheme = sslEnabled ? "https" : "http";
        String port = environment.getProperty("local.server.port", environment.getProperty("server.port", "8080"));
        String contextPath = environment.getProperty("server.servlet.context-path", "");
        return scheme + "://localhost:" + port + contextPath + properties.getPath();
    }
}
