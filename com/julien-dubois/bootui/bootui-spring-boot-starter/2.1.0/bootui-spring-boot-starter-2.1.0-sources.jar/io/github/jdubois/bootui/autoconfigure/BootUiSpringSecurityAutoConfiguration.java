package io.github.jdubois.bootui.autoconfigure;

import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.autoconfigure.AutoConfiguration;
import org.springframework.boot.autoconfigure.condition.ConditionalOnBean;
import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.autoconfigure.condition.ConditionalOnWebApplication;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Conditional;
import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.csrf.CsrfFilter;
import org.springframework.security.web.csrf.CsrfToken;
import org.springframework.web.filter.OncePerRequestFilter;

/**
 * Opens BootUI's own route inside Spring Security while keeping the localhost-only
 * servlet filter as the outer safety boundary.
 */
@AutoConfiguration(
        afterName = "org.springframework.boot.security.autoconfigure.web.servlet.ServletWebSecurityAutoConfiguration")
@Conditional(BootUiActivationCondition.class)
@ConditionalOnWebApplication(type = ConditionalOnWebApplication.Type.SERVLET)
@ConditionalOnClass(
        name = {
            "org.springframework.security.config.annotation.web.builders.HttpSecurity",
            "org.springframework.security.web.SecurityFilterChain"
        })
@ConditionalOnBean(HttpSecurity.class)
@EnableConfigurationProperties(BootUiProperties.class)
public class BootUiSpringSecurityAutoConfiguration {

    private static final Logger log = LoggerFactory.getLogger(BootUiSpringSecurityAutoConfiguration.class);

    @Bean
    @Order(Ordered.HIGHEST_PRECEDENCE)
    @ConditionalOnMissingBean(name = "bootUiSecurityFilterChain")
    public SecurityFilterChain bootUiSecurityFilterChain(HttpSecurity http, BootUiProperties properties)
            throws Exception {
        String[] bootUiPatterns = bootUiSecurityPatterns(properties);
        String otlpPattern = childSecurityPattern(properties.getApiPath(), "otlp");
        String mcpPattern = childSecurityEndpoint(properties.getApiPath(), "mcp");
        String mcpDescendantsPattern = childSecurityPattern(properties.getApiPath(), "mcp");
        String cliPattern = childSecurityEndpoint(properties.getApiPath(), "cli");
        String cliDescendantsPattern = childSecurityPattern(properties.getApiPath(), "cli");
        String mcpTogglePattern = childSecurityEndpoint(properties.getApiPath(), "mcp-server/toggle");
        String authSessionPattern = childSecurityEndpoint(properties.getApiPath(), "auth/session");
        log.warn(
                "BootUI detected Spring Security and is permitting unauthenticated access to {}; "
                        + "BootUI's localhost-only filter still rejects non-loopback callers unless "
                        + "bootui.allow-non-localhost=true is set.",
                String.join(", ", bootUiPatterns));
        return http.securityMatcher(bootUiPatterns)
                .authorizeHttpRequests(authorize -> authorize.anyRequest().permitAll())
                // OTLP ingest, the MCP JSON-RPC endpoint, the CLI endpoint, and the MCP server toggle the CLI
                // drives are called by non-browser programmatic clients (OpenTelemetry exporters, local AI
                // agents, the bootui CLI) that cannot present BootUI's SPA CSRF token, so they are exempted
                // here. Only the exact toggle path is exempt, not the rest of the mcp-server panel. They
                // remain protected from cross-site writes by LocalhostOnlyFilter's loopback, Host allow-list,
                // and Origin/Sec-Fetch-Site checks.
                .csrf(csrf -> csrf.spa()
                        .ignoringRequestMatchers(
                                otlpPattern,
                                mcpPattern,
                                mcpDescendantsPattern,
                                cliPattern,
                                cliDescendantsPattern,
                                mcpTogglePattern,
                                authSessionPattern))
                .addFilterAfter(new CsrfCookieFilter(), CsrfFilter.class)
                .build();
    }

    static String[] bootUiSecurityPatterns(BootUiProperties properties) {
        String uiBasePath = withoutTrailingSlash(properties.getPath());
        String apiBasePath = withoutTrailingSlash(properties.getApiPath());
        return new String[] {uiBasePath, securityPattern(uiBasePath), apiBasePath, securityPattern(apiBasePath)};
    }

    private static String securityPattern(String basePath) {
        String normalized = withoutTrailingSlash(basePath);
        return normalized + "/**";
    }

    private static String childSecurityPattern(String basePath, String childPath) {
        return childSecurityEndpoint(basePath, childPath) + "/**";
    }

    private static String childSecurityEndpoint(String basePath, String childPath) {
        return withoutTrailingSlash(basePath) + "/" + childPath;
    }

    private static String withoutTrailingSlash(String path) {
        if (path == null || path.isBlank()) {
            throw new IllegalArgumentException("BootUI path must not be blank");
        }
        if (path.length() > 1 && path.endsWith("/")) {
            return path.substring(0, path.length() - 1);
        }
        return path;
    }

    private static final class CsrfCookieFilter extends OncePerRequestFilter {

        @Override
        protected void doFilterInternal(
                HttpServletRequest request, HttpServletResponse response, FilterChain filterChain)
                throws ServletException, IOException {
            CsrfToken csrfToken = (CsrfToken) request.getAttribute(CsrfToken.class.getName());
            if (csrfToken != null) {
                csrfToken.getToken();
            }
            filterChain.doFilter(request, response);
        }
    }
}
