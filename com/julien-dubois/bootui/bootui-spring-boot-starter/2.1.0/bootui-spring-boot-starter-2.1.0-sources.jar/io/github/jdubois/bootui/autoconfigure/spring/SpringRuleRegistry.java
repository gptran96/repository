package io.github.jdubois.bootui.autoconfigure.spring;

import java.util.List;

/**
 * Fixed, reviewable registry of the curated Spring Advisor rules. Adding a rule means adding one
 * focused class plus an entry here; the panel never derives rules from project-specific input.
 */
final class SpringRuleRegistry {

    private static final List<SpringRule> ACTIVE_RULES = List.of(
            // Bean wiring
            new BeanDefinitionOverridingRule(),
            new CircularReferencesAllowedRule(),
            new DuplicateObjectMapperRule(),
            new AmbiguousTaskExecutorRule(),
            new AmbiguousDataSourceRule(),
            new AmbiguousTransactionManagerRule(),
            new RestTemplateInUseRule(),
            new DefaultPackageComponentsRule(),
            new MutableSingletonFieldRule(),
            // Configuration
            new DebugOrTraceLoggingRule(),
            new RemovedOrRenamedPropertyRule(),
            new MissingApplicationNameRule(),
            new ConfigOnNotFoundIgnoreRule(),
            new Jackson2DefaultsCompatibilityRule(),
            new Jackson2AutoConfigurationActiveRule(),
            new PropertiesMigratorPresentRule(),
            // Profiles and environment
            new DevToolsOnClasspathRule(),
            new ProfileValidationDisabledRule(),
            // Performance and concurrency
            new VirtualThreadsAvailableRule(),
            new VirtualThreadsOverriddenByPoolRule(),
            new AsyncWithoutCustomExecutorRule(),
            new SchedulerPoolTooSmallRule(),
            new UnboundedAsyncQueueRule(),
            new VirtualThreadsBeforeJep491Rule(),
            new InMemoryCacheManagerRule(),
            // Web and HTTP
            new ResponseCompressionDisabledRule(),
            new GracefulShutdownDisabledRule(),
            new Http2DisabledRule(),
            new ErrorDetailsExposedRule(),
            new HttpClientTimeoutsUnsetRule(),
            new RedundantTomcatThreadsRule(),
            new UnlimitedMultipartRequestRule(),
            // Data and persistence
            new OpenSessionInViewEnabledRule(),
            new InMemoryDatasourceInProductionRule(),
            new InMemoryR2dbcInProductionRule(),
            // Actuator and management
            new ActuatorExposeAllRule(),
            new SensitiveActuatorEndpointsExposedRule(),
            new ActuatorShowValuesAlwaysRule(),
            new DangerousActuatorEndpointsAccessibleRule(),
            // Reactive (WebFlux only)
            new ReactiveHandlerWithBlockingDatasourceRule(),
            new UnlimitedCodecAggregationRule());

    private SpringRuleRegistry() {}

    static List<SpringRule> activeRules() {
        return ACTIVE_RULES;
    }
}
