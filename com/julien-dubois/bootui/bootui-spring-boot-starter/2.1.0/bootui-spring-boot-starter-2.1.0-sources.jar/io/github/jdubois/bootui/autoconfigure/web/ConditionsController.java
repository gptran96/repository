package io.github.jdubois.bootui.autoconfigure.web;

import io.github.jdubois.bootui.autoconfigure.monitoring.BootUiSelfDataFilter;
import io.github.jdubois.bootui.core.dto.ConditionCounts;
import io.github.jdubois.bootui.core.dto.ConditionEntry;
import io.github.jdubois.bootui.core.dto.ConditionsReport;
import io.github.jdubois.bootui.engine.support.PagedList;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import org.springframework.beans.factory.ObjectProvider;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.actuate.autoconfigure.condition.ConditionsReportEndpoint;
import org.springframework.boot.actuate.autoconfigure.condition.ConditionsReportEndpoint.ConditionsDescriptor;
import org.springframework.boot.actuate.autoconfigure.condition.ConditionsReportEndpoint.ContextConditionsDescriptor;
import org.springframework.boot.actuate.autoconfigure.condition.ConditionsReportEndpoint.MessageAndConditionDescriptor;
import org.springframework.boot.actuate.autoconfigure.condition.ConditionsReportEndpoint.MessageAndConditionsDescriptor;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("${bootui.api-path:${bootui.path:/bootui}/api}/conditions")
public class ConditionsController {

    private final ObjectProvider<ConditionsReportEndpoint> endpoint;

    private final BootUiSelfDataFilter selfDataFilter;

    public ConditionsController(ObjectProvider<ConditionsReportEndpoint> endpoint) {
        this(endpoint, BootUiSelfDataFilter.defaults());
    }

    @Autowired
    public ConditionsController(
            ObjectProvider<ConditionsReportEndpoint> endpoint, BootUiSelfDataFilter selfDataFilter) {
        this.endpoint = endpoint;
        this.selfDataFilter = selfDataFilter;
    }

    @GetMapping
    public ConditionsReport conditions(
            @RequestParam(name = "q", required = false) String query,
            @RequestParam(name = "outcome", required = false) String outcome,
            @RequestParam(name = "offset", required = false) Integer offset,
            @RequestParam(name = "limit", required = false) Integer limit) {
        ConditionsReportEndpoint cre = endpoint.getIfAvailable();
        if (cre == null) {
            return new ConditionsReport(List.of(), List.of(), List.of(), List.of());
        }
        ConditionsDescriptor descriptor = cre.conditions();
        List<ConditionEntry> positive = new ArrayList<>();
        List<ConditionEntry> negative = new ArrayList<>();
        List<String> unconditional = new ArrayList<>();
        List<String> exclusions = new ArrayList<>();

        for (Map.Entry<String, ContextConditionsDescriptor> ctx :
                descriptor.getContexts().entrySet()) {
            ContextConditionsDescriptor ccd = ctx.getValue();
            for (Map.Entry<String, List<MessageAndConditionDescriptor>> e :
                    ccd.getPositiveMatches().entrySet()) {
                if (!selfDataFilter.shouldIncludeConditionClass(e.getKey())) {
                    continue;
                }
                for (MessageAndConditionDescriptor m : e.getValue()) {
                    positive.add(new ConditionEntry(e.getKey(), m.getCondition(), m.getMessage(), "MATCH"));
                }
            }
            for (Map.Entry<String, MessageAndConditionsDescriptor> e :
                    ccd.getNegativeMatches().entrySet()) {
                if (!selfDataFilter.shouldIncludeConditionClass(e.getKey())) {
                    continue;
                }
                MessageAndConditionsDescriptor v = e.getValue();
                if (v.getNotMatched() != null) {
                    for (MessageAndConditionDescriptor m : v.getNotMatched()) {
                        negative.add(new ConditionEntry(e.getKey(), m.getCondition(), m.getMessage(), "NO_MATCH"));
                    }
                }
                if (v.getMatched() != null) {
                    for (MessageAndConditionDescriptor m : v.getMatched()) {
                        positive.add(new ConditionEntry(e.getKey(), m.getCondition(), m.getMessage(), "PARTIAL"));
                    }
                }
            }
            Set<String> uc = ccd.getUnconditionalClasses();
            if (uc != null) {
                unconditional.addAll(uc.stream()
                        .filter(selfDataFilter::shouldIncludeConditionClass)
                        .toList());
            }
            List<String> ex = ccd.getExclusions();
            if (ex != null) {
                exclusions.addAll(ex.stream()
                        .filter(selfDataFilter::shouldIncludeConditionClass)
                        .toList());
            }
        }
        positive.sort(conditionComparator());
        negative.sort(conditionComparator());
        unconditional.sort(String::compareTo);
        exclusions.sort(String::compareTo);

        String normalizedQuery = PagedList.normalize(query);
        List<ConditionEntry> positiveFiltered = positive.stream()
                .filter(entry -> matchesQuery(entry, normalizedQuery))
                .toList();
        List<ConditionEntry> negativeFiltered = negative.stream()
                .filter(entry -> matchesQuery(entry, normalizedQuery))
                .toList();
        ConditionCounts counts = new ConditionCounts(
                positive.size(),
                positiveFiltered.size(),
                negative.size(),
                negativeFiltered.size(),
                unconditional.size(),
                exclusions.size());

        String normalizedOutcome = PagedList.normalize(outcome);
        // Without an outcome (the agents' read), a query also narrows the class lists, which carry no outcome; their
        // counts stay totals. The browser always asks for an outcome and keeps the whole lists.
        boolean narrowLists = normalizedOutcome.isEmpty();
        List<String> unconditionalShown = narrowLists
                ? unconditional.stream()
                        .filter(name -> PagedList.contains(name, normalizedQuery))
                        .toList()
                : unconditional;
        List<String> exclusionsShown = narrowLists
                ? exclusions.stream()
                        .filter(name -> PagedList.contains(name, normalizedQuery))
                        .toList()
                : exclusions;

        if ("positive".equals(normalizedOutcome)) {
            PagedList.Result<ConditionEntry> page =
                    PagedList.from(positive, entry -> matchesQuery(entry, normalizedQuery), offset, limit);
            return new ConditionsReport(
                    page.items(), List.of(), unconditionalShown, exclusionsShown, page.page(), counts);
        }
        if ("negative".equals(normalizedOutcome)) {
            PagedList.Result<ConditionEntry> page =
                    PagedList.from(negative, entry -> matchesQuery(entry, normalizedQuery), offset, limit);
            return new ConditionsReport(
                    List.of(), page.items(), unconditionalShown, exclusionsShown, page.page(), counts);
        }

        // Both outcomes: one page over the positive matches, then the negative ones.
        List<ConditionEntry> both = new ArrayList<>(positive.size() + negative.size());
        both.addAll(positive);
        both.addAll(negative);
        PagedList.Result<ConditionEntry> page =
                PagedList.from(both, entry -> matchesQuery(entry, normalizedQuery), offset, limit);
        List<ConditionEntry> positivePage = new ArrayList<>();
        List<ConditionEntry> negativePage = new ArrayList<>();
        for (int i = 0; i < page.items().size(); i++) {
            boolean matchedPositive = page.page().offset() + i < positiveFiltered.size();
            (matchedPositive ? positivePage : negativePage).add(page.items().get(i));
        }
        return new ConditionsReport(
                positivePage, negativePage, unconditionalShown, exclusionsShown, page.page(), counts);
    }

    private Comparator<ConditionEntry> conditionComparator() {
        return Comparator.comparing(ConditionEntry::autoConfigurationClass, Comparator.nullsLast(String::compareTo))
                .thenComparing(ConditionEntry::condition, Comparator.nullsLast(String::compareTo))
                .thenComparing(ConditionEntry::message, Comparator.nullsLast(String::compareTo))
                .thenComparing(ConditionEntry::outcome, Comparator.nullsLast(String::compareTo));
    }

    private boolean matchesQuery(ConditionEntry entry, String query) {
        return PagedList.contains(entry.autoConfigurationClass(), query)
                || PagedList.contains(entry.condition(), query)
                || PagedList.contains(entry.message(), query)
                || PagedList.contains(entry.outcome(), query);
    }
}
