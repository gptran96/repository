package io.github.jdubois.bootui.autoconfigure.web;

import io.github.jdubois.bootui.core.DevToolsException;
import io.github.jdubois.bootui.core.dto.DevToolsActionResult;
import io.github.jdubois.bootui.core.dto.DevToolsStatus;
import jakarta.annotation.PreDestroy;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.Collection;
import java.util.Map;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.util.ClassUtils;

public class DefaultDevToolsBridge implements DevToolsBridge {

    private static final Logger log = LoggerFactory.getLogger(DefaultDevToolsBridge.class);

    private static final String RESTARTER_CLASS = "org.springframework.boot.devtools.restart.Restarter";

    private static final String LIVE_RELOAD_SERVER_CLASS =
            "org.springframework.boot.devtools.livereload.LiveReloadServer";

    private static final String OPTIONAL_LIVE_RELOAD_SERVER_CLASS =
            "org.springframework.boot.devtools.autoconfigure.OptionalLiveReloadServer";

    private static final int DEFAULT_LIVE_RELOAD_PORT = 35729;

    private final ApplicationContext applicationContext;

    private final ClassLoader classLoader;

    private final AtomicBoolean restartPending = new AtomicBoolean(false);
    private final ScheduledExecutorService restartExecutor =
            Executors.newSingleThreadScheduledExecutor(r -> new Thread(r, "bootui-devtools-restart"));

    public DefaultDevToolsBridge(ApplicationContext applicationContext) {
        this.applicationContext = applicationContext;
        this.classLoader = applicationContext.getClassLoader() == null
                ? ClassUtils.getDefaultClassLoader()
                : applicationContext.getClassLoader();
    }

    @Override
    public DevToolsStatus status() {
        Availability restart = restartAvailability();
        LiveReloadHandle liveReload = liveReloadHandle();
        return new DevToolsStatus(
                restart.available(),
                restart.reason(),
                restartPending.get(),
                liveReload.available(),
                liveReload.port(),
                liveReload.connections(),
                liveReload.reason());
    }

    @Override
    public DevToolsActionResult triggerLiveReload() {
        LiveReloadHandle liveReload = liveReloadHandle();
        if (!liveReload.available()) {
            return new DevToolsActionResult("livereload", "unavailable", liveReload.reason());
        }
        try {
            Method triggerReload = liveReload.target().getClass().getMethod("triggerReload");
            triggerReload.invoke(liveReload.target());
        } catch (ReflectiveOperationException ex) {
            throw new DevToolsException("Could not trigger Spring Boot DevTools LiveReload", unwrap(ex));
        }
        int connections = liveReload.connections();
        if (connections <= 0) {
            int port = liveReload.port() == null ? DEFAULT_LIVE_RELOAD_PORT : liveReload.port();
            return new DevToolsActionResult(
                    "livereload",
                    "no_clients",
                    "LiveReload command sent, but no browsers are connected on port " + port
                            + ", so nothing reloaded. Spring Boot does not inject livereload.js: install the LiveReload"
                            + " browser extension and reload the page you want to refresh so it connects, then trigger"
                            + " again.");
        }
        return new DevToolsActionResult(
                "livereload",
                "triggered",
                "LiveReload command sent to " + connections + " connected client" + (connections == 1 ? "" : "s")
                        + ".");
    }

    @Override
    public DevToolsActionResult scheduleRestart() {
        Availability restart = restartAvailability();
        if (!restart.available()) {
            return new DevToolsActionResult("restart", "unavailable", restart.reason());
        }
        if (!restartPending.compareAndSet(false, true)) {
            return new DevToolsActionResult("restart", "already_pending", "A DevTools restart is already pending.");
        }

        Object restarter = restarter();
        restartExecutor.schedule(() -> restartAfterResponse(restarter), 250, TimeUnit.MILLISECONDS);
        return new DevToolsActionResult(
                "restart",
                "scheduled",
                "Restart scheduled. BootUI will reconnect when the application is available again.");
    }

    @PreDestroy
    public void stop() {
        restartExecutor.shutdownNow();
    }

    private void restartAfterResponse(Object restarter) {
        try {
            Method restart = restarter.getClass().getMethod("restart");
            restart.invoke(restarter);
        } catch (ReflectiveOperationException ex) {
            restartPending.set(false);
            log.warn("Spring Boot DevTools restart failed", unwrap(ex));
        } catch (Exception ex) {
            restartPending.set(false);
            log.warn("Spring Boot DevTools restart failed", ex);
        }
    }

    private Availability restartAvailability() {
        if (!ClassUtils.isPresent(RESTARTER_CLASS, classLoader)) {
            return Availability.unavailable("spring-boot-devtools is not on the classpath.");
        }
        try {
            restarter();
            return Availability.ready();
        } catch (DevToolsException ex) {
            return Availability.unavailable(unavailableReason(ex));
        }
    }

    /**
     * A status read must always degrade to an honest reason, so fall back to a generic explanation when the
     * wrapped DevTools failure carries no message of its own.
     */
    private String unavailableReason(DevToolsException ex) {
        String message = ex.getMessage();
        return message == null || message.isBlank() ? "Spring Boot DevTools Restarter is not available." : message;
    }

    private Object restarter() {
        try {
            Class<?> restarterClass = ClassUtils.forName(RESTARTER_CLASS, classLoader);
            Method getInstance = restarterClass.getMethod("getInstance");
            return getInstance.invoke(null);
        } catch (InvocationTargetException ex) {
            Throwable cause = ex.getTargetException();
            throw new DevToolsException(
                    cause.getMessage() == null
                            ? "Spring Boot DevTools Restarter is not initialized."
                            : cause.getMessage(),
                    cause);
        } catch (ReflectiveOperationException | LinkageError ex) {
            throw new DevToolsException("Spring Boot DevTools Restarter is not available.", ex);
        }
    }

    private LiveReloadHandle liveReloadHandle() {
        if (!ClassUtils.isPresent(OPTIONAL_LIVE_RELOAD_SERVER_CLASS, classLoader)
                && !ClassUtils.isPresent(LIVE_RELOAD_SERVER_CLASS, classLoader)) {
            return LiveReloadHandle.unavailable("Spring Boot DevTools LiveReload is not on the classpath.");
        }
        LiveReloadHandle optional = beanHandle(OPTIONAL_LIVE_RELOAD_SERVER_CLASS);
        if (optional.available()) {
            return optional;
        }
        LiveReloadHandle server = beanHandle(LIVE_RELOAD_SERVER_CLASS);
        if (server.available()) {
            return server;
        }
        return LiveReloadHandle.unavailable("Spring Boot DevTools LiveReload server is not available.");
    }

    private LiveReloadHandle beanHandle(String className) {
        if (!ClassUtils.isPresent(className, classLoader)) {
            return LiveReloadHandle.unavailable(null);
        }
        try {
            Class<?> type = ClassUtils.forName(className, classLoader);
            Map<String, ?> beans = applicationContext.getBeansOfType(type, false, false);
            if (beans.isEmpty()) {
                return LiveReloadHandle.unavailable(null);
            }
            Object bean = beans.values().iterator().next();
            Object server = liveReloadServer(bean);
            return new LiveReloadHandle(bean, liveReloadPort(server), connectionCount(server), null);
        } catch (ReflectiveOperationException | LinkageError ex) {
            return LiveReloadHandle.unavailable("Spring Boot DevTools LiveReload server is not available.");
        }
    }

    private Integer liveReloadPort(Object server) {
        if (server == null) {
            return null;
        }
        try {
            Method getPort = server.getClass().getMethod("getPort");
            return (Integer) getPort.invoke(server);
        } catch (ReflectiveOperationException ex) {
            return null;
        }
    }

    private int connectionCount(Object server) {
        if (server == null) {
            return 0;
        }
        try {
            Field connections = server.getClass().getDeclaredField("connections");
            connections.setAccessible(true);
            if (connections.get(server) instanceof Collection<?> collection) {
                synchronized (collection) {
                    return collection.size();
                }
            }
            return 0;
        } catch (ReflectiveOperationException ex) {
            return 0;
        }
    }

    private Object liveReloadServer(Object bean) {
        if (bean.getClass().getName().equals(LIVE_RELOAD_SERVER_CLASS)) {
            return bean;
        }
        try {
            Field server = bean.getClass().getDeclaredField("server");
            server.setAccessible(true);
            return server.get(bean);
        } catch (ReflectiveOperationException ex) {
            return null;
        }
    }

    private Throwable unwrap(ReflectiveOperationException ex) {
        return ex instanceof InvocationTargetException invocation && invocation.getTargetException() != null
                ? invocation.getTargetException()
                : ex;
    }

    private record Availability(boolean available, String reason) {

        static Availability ready() {
            return new Availability(true, null);
        }

        static Availability unavailable(String reason) {
            return new Availability(false, reason);
        }
    }

    private record LiveReloadHandle(Object target, Integer port, int connections, String reason) {

        static LiveReloadHandle unavailable(String reason) {
            return new LiveReloadHandle(null, null, 0, reason);
        }

        boolean available() {
            return target != null;
        }
    }
}
