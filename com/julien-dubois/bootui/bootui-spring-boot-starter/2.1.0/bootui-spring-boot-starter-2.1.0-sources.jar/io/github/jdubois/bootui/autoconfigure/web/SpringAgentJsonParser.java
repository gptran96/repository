package io.github.jdubois.bootui.autoconfigure.web;

import io.github.jdubois.bootui.spi.agent.AgentJson;
import io.github.jdubois.bootui.spi.agent.AgentJsonParser;
import java.io.IOException;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import tools.jackson.databind.JsonNode;
import tools.jackson.databind.ObjectMapper;

/**
 * Spring Boot agent JSON parser over Jackson 3 ({@code tools.jackson}). Keeps the engine session store
 * free of any Jackson dependency by handing it neutral {@link AgentJson} trees.
 */
public class SpringAgentJsonParser implements AgentJsonParser {

    private final ObjectMapper objectMapper = new ObjectMapper();

    @Override
    public AgentJson parseTree(Path file) throws IOException {
        return wrap(objectMapper.readTree(file.toFile()));
    }

    @Override
    public AgentJson parseLine(String line) {
        return wrap(objectMapper.readTree(line));
    }

    private static AgentJson wrap(JsonNode node) {
        return node == null ? null : new JacksonAgentJson(node);
    }

    private record JacksonAgentJson(JsonNode node) implements AgentJson {

        @Override
        public AgentJson get(String fieldName) {
            return wrap(node.get(fieldName));
        }

        @Override
        public AgentJson get(int index) {
            return wrap(node.get(index));
        }

        @Override
        public boolean isNull() {
            return node.isNull();
        }

        @Override
        public boolean isArray() {
            return node.isArray();
        }

        @Override
        public boolean isObject() {
            return node.isObject();
        }

        @Override
        public boolean isString() {
            return node.isString();
        }

        @Override
        public boolean isBoolean() {
            return node.isBoolean();
        }

        @Override
        public int size() {
            return node.size();
        }

        @Override
        public boolean canConvertToLong() {
            return node.canConvertToLong();
        }

        @Override
        public String asString() {
            return node.asString();
        }

        @Override
        public long asLong() {
            return node.asLong();
        }

        @Override
        public boolean asBoolean() {
            return node.asBoolean();
        }

        @Override
        public List<Map.Entry<String, AgentJson>> properties() {
            List<Map.Entry<String, AgentJson>> entries = new ArrayList<>();
            node.properties()
                    .forEach(e -> entries.add(Map.entry(e.getKey(), (AgentJson) new JacksonAgentJson(e.getValue()))));
            return entries;
        }

        @Override
        public String toPrettyString() {
            return node.toPrettyString();
        }
    }
}
