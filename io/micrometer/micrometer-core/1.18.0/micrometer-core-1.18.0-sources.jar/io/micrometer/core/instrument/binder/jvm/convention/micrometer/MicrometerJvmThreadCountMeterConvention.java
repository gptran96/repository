/*
 * Copyright 2026 VMware, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.micrometer.core.instrument.binder.jvm.convention.micrometer;

import io.micrometer.core.instrument.Tags;
import io.micrometer.core.instrument.binder.jvm.convention.JvmThreadCountMeterConvention;

import java.util.Locale;

/**
 * Historical convention used in Micrometer-provided JVM thread count metrics.
 *
 * @see io.micrometer.core.instrument.binder.jvm.JvmThreadMetrics
 * @since 1.18.0
 */
public class MicrometerJvmThreadCountMeterConvention implements JvmThreadCountMeterConvention {

    @Override
    public String getName() {
        return "jvm.threads.states";
    }

    @Override
    public Tags getTags(Thread.State state) {
        return Tags.of("state", state.name().toLowerCase(Locale.ROOT).replace('_', '-'));
    }

}
