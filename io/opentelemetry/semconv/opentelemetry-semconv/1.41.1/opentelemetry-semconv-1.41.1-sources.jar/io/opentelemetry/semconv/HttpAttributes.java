/*
 * Copyright The OpenTelemetry Authors
 * SPDX-License-Identifier: Apache-2.0
 */

package io.opentelemetry.semconv;

import static io.opentelemetry.api.common.AttributeKey.longKey;
import static io.opentelemetry.api.common.AttributeKey.stringKey;
import static io.opentelemetry.semconv.AttributeKeyTemplate.stringArrayKeyTemplate;

import io.opentelemetry.api.common.AttributeKey;
import java.util.List;

// DO NOT EDIT, this is an Auto-generated file from
// buildscripts/templates/registry/java/SemanticAttributes.java.j2
@SuppressWarnings("unused")
public final class HttpAttributes {
  /**
   * HTTP request headers, {@code <key>} being the normalized HTTP Header name (lowercase), the
   * value being the header values.
   *
   * <p>Notes:
   *
   * <p>Instrumentations SHOULD require an explicit configuration of which headers are to be
   * captured. Including all request headers can be a security risk - explicit configuration helps
   * avoid leaking sensitive information.
   *
   * <p>The {@code User-Agent} header is already captured in the {@code user_agent.original}
   * attribute. Users MAY explicitly configure instrumentations to capture them even though it is
   * not recommended.
   *
   * <p>The attribute value MUST consist of either multiple header values as an array of strings or
   * a single-item array containing a possibly comma-concatenated string, depending on the way the
   * HTTP library provides access to headers.
   *
   * <p>Examples:
   *
   * <ul>
   *   <li>A header {@code Content-Type: application/json} SHOULD be recorded as the {@code
   *       http.request.header.content-type} attribute with value {@code ["application/json"]}.
   *   <li>A header {@code X-Forwarded-For: 1.2.3.4, 1.2.3.5} SHOULD be recorded as the {@code
   *       http.request.header.x-forwarded-for} attribute with value {@code ["1.2.3.4", "1.2.3.5"]}
   *       or {@code ["1.2.3.4, 1.2.3.5"]} depending on the HTTP library.
   * </ul>
   */
  public static final AttributeKeyTemplate<List<String>> HTTP_REQUEST_HEADER =
      stringArrayKeyTemplate("http.request.header");

  /**
   * HTTP request method.
   *
   * <p>Notes:
   *
   * <p>HTTP request method value SHOULD be "known" to the instrumentation. By default, this
   * convention defines "known" methods as the ones listed in <a
   * href="https://www.rfc-editor.org/rfc/rfc9110.html#name-methods">RFC9110</a>, the PATCH method
   * defined in <a href="https://www.rfc-editor.org/rfc/rfc5789.html">RFC5789</a> and the QUERY
   * method defined in <a
   * href="https://datatracker.ietf.org/doc/draft-ietf-httpbis-safe-method-w-body/?include_text=1">httpbis-safe-method-w-body</a>.
   *
   * <p>If the HTTP request method is not known to instrumentation, it MUST set the {@code
   * http.request.method} attribute to {@code _OTHER}.
   *
   * <p>If the HTTP instrumentation could end up converting valid HTTP request methods to {@code
   * _OTHER}, then it MUST provide a way to override the list of known HTTP methods. If this
   * override is done via environment variable, then the environment variable MUST be named
   * OTEL_INSTRUMENTATION_HTTP_KNOWN_METHODS and support a comma-separated list of case-sensitive
   * known HTTP methods.
   *
   * <p>If this override is done via declarative configuration, then the list MUST be configurable
   * via the {@code known_methods} property (an array of case-sensitive strings with minimum items
   * 0) under {@code .instrumentation/development.general.http.client} and/or {@code
   * .instrumentation/development.general.http.server}.
   *
   * <p>In either case, this list MUST be a full override of the default known methods, it is not a
   * list of known methods in addition to the defaults.
   *
   * <p>HTTP method names are case-sensitive and {@code http.request.method} attribute value MUST
   * match a known HTTP method name exactly. Instrumentations for specific web frameworks that
   * consider HTTP methods to be case insensitive, SHOULD populate a canonical equivalent. Tracing
   * instrumentations that do so, MUST also set {@code http.request.method_original} to the original
   * value.
   */
  public static final AttributeKey<String> HTTP_REQUEST_METHOD = stringKey("http.request.method");

  /** Original HTTP method sent by the client in the request line. */
  public static final AttributeKey<String> HTTP_REQUEST_METHOD_ORIGINAL =
      stringKey("http.request.method_original");

  /**
   * The ordinal number of request resending attempt (for any reason, including redirects).
   *
   * <p>Notes:
   *
   * <p>The resend count SHOULD be updated each time an HTTP request gets resent by the client,
   * regardless of what was the cause of the resending (e.g. redirection, authorization failure, 503
   * Server Unavailable, network issues, or any other).
   */
  public static final AttributeKey<Long> HTTP_REQUEST_RESEND_COUNT =
      longKey("http.request.resend_count");

  /**
   * HTTP response headers, {@code <key>} being the normalized HTTP Header name (lowercase), the
   * value being the header values.
   *
   * <p>Notes:
   *
   * <p>Instrumentations SHOULD require an explicit configuration of which headers are to be
   * captured. Including all response headers can be a security risk - explicit configuration helps
   * avoid leaking sensitive information.
   *
   * <p>Users MAY explicitly configure instrumentations to capture them even though it is not
   * recommended.
   *
   * <p>The attribute value MUST consist of either multiple header values as an array of strings or
   * a single-item array containing a possibly comma-concatenated string, depending on the way the
   * HTTP library provides access to headers.
   *
   * <p>Examples:
   *
   * <ul>
   *   <li>A header {@code Content-Type: application/json} header SHOULD be recorded as the {@code
   *       http.request.response.content-type} attribute with value {@code ["application/json"]}.
   *   <li>A header {@code My-custom-header: abc, def} header SHOULD be recorded as the {@code
   *       http.response.header.my-custom-header} attribute with value {@code ["abc", "def"]} or
   *       {@code ["abc, def"]} depending on the HTTP library.
   * </ul>
   */
  public static final AttributeKeyTemplate<List<String>> HTTP_RESPONSE_HEADER =
      stringArrayKeyTemplate("http.response.header");

  /** <a href="https://tools.ietf.org/html/rfc7231#section-6">HTTP response status code</a>. */
  public static final AttributeKey<Long> HTTP_RESPONSE_STATUS_CODE =
      longKey("http.response.status_code");

  /**
   * The matched route template for the request. This MUST be low-cardinality and include all static
   * path segments, with dynamic path segments represented with placeholders.
   *
   * <p>Notes:
   *
   * <p>MUST NOT be populated when this is not supported by the HTTP server framework as the route
   * attribute should have low-cardinality and the URI path can NOT substitute it. SHOULD include
   * the <a href="/docs/http/http-spans.md#http-server-definitions">application root</a> if there is
   * one.
   *
   * <p>A static path segment is a part of the route template with a fixed, low-cardinality value.
   * This includes literal strings like {@code /users/} and placeholders that are constrained to a
   * finite, predefined set of values, e.g. {@code {controller}} or {@code {action}}.
   *
   * <p>A dynamic path segment is a placeholder for a value that can have high cardinality and is
   * not constrained to a predefined list like static path segments.
   *
   * <p>Instrumentations SHOULD use routing information provided by the corresponding web framework.
   * They SHOULD pick the most precise source of routing information and MAY support custom route
   * formatting. Instrumentations SHOULD document the format and the API used to obtain the route
   * string.
   */
  public static final AttributeKey<String> HTTP_ROUTE = stringKey("http.route");

  // Enum definition
  /** Values for {@link #HTTP_REQUEST_METHOD}. */
  public static final class HttpRequestMethodValues {
    /** CONNECT method. */
    public static final String CONNECT = "CONNECT";

    /** DELETE method. */
    public static final String DELETE = "DELETE";

    /** GET method. */
    public static final String GET = "GET";

    /** HEAD method. */
    public static final String HEAD = "HEAD";

    /** OPTIONS method. */
    public static final String OPTIONS = "OPTIONS";

    /** PATCH method. */
    public static final String PATCH = "PATCH";

    /** POST method. */
    public static final String POST = "POST";

    /** PUT method. */
    public static final String PUT = "PUT";

    /** TRACE method. */
    public static final String TRACE = "TRACE";

    /** Any HTTP method that the instrumentation has no prior knowledge of. */
    public static final String OTHER = "_OTHER";

    private HttpRequestMethodValues() {}
  }

  private HttpAttributes() {}
}
