package net.logstash.logback.encoder.com.lmax.disruptor;

public interface EventHandlerIdentity
{
}
