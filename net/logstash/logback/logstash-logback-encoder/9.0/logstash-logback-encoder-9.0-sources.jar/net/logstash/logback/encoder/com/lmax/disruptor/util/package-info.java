/**
 * Utility classes
 */
package net.logstash.logback.encoder.com.lmax.disruptor.util;