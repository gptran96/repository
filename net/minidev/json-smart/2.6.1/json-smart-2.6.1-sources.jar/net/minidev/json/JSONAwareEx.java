package net.minidev.json;

/*
 *    Copyright 2011-2025 JSON-SMART authors
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
/**
 * Beans that support advanced output of JSON text shall implement this interface.
 *
 * <p>Adding compressions and formating features
 *
 * @author Uriel Chemouni &lt;uchemouni@gmail.com&gt;
 */
public interface JSONAwareEx extends JSONAware {
  /**
   * Converts this object to JSON string representation with specified compression style.
   *
   * @param compression the JSON style for formatting
   * @return JSON text
   */
  String toJSONString(JSONStyle compression);
}
