package org.bouncycastle.asn1;

import java.io.IOException;
import java.util.Enumeration;
import java.util.NoSuchElementException;

class LazyConstructionEnumeration
    implements Enumeration
{
    private ASN1InputStream aIn;
    private Object          nextObj;

    public LazyConstructionEnumeration(byte[] encoded, int depth)
    {
        aIn = new ASN1InputStream(encoded, true, depth);
        nextObj = readObject();
    }

    public boolean hasMoreElements()
    {
        return nextObj != null;
    }

    public Object nextElement()
    {
        if (nextObj != null)
        {
            Object o = nextObj;
            nextObj = readObject();
            return o;
        }
        throw new NoSuchElementException();
    }

    private Object readObject()
    {
        try
        {
            return aIn.readObject();
        }
        catch (IOException e)
        {
            throw new ASN1ParsingException("malformed ASN.1: " + e, e);
        }
    }
}
