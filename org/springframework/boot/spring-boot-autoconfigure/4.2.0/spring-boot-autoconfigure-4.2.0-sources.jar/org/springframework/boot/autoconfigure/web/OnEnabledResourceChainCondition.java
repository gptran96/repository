/*
 * Copyright 2012-present the original author or authors.
 */

package org.springframework.boot.autoconfigure.web;

import org.jspecify.annotations.Nullable;

import org.springframework.boot.autoconfigure.condition.ConditionMessage;
import org.springframework.boot.autoconfigure.condition.ConditionOutcome;
import org.springframework.boot.autoconfigure.condition.SpringBootCondition;
import org.springframework.boot.autoconfigure.web.WebProperties.Resources.Chain;
import org.springframework.context.annotation.Condition;
import org.springframework.context.annotation.ConditionContext;
import org.springframework.core.env.ConfigurableEnvironment;
import org.springframework.core.type.AnnotatedTypeMetadata;
import org.springframework.lang.Contract;
import org.springframework.util.ClassUtils;

/**
 * {@link Condition} that checks whether the Spring resource handling chain is enabled.
 *
 * @author Stephane Nicoll
 * @author Phillip Webb
 * @author Madhura Bhave
 * @author Brian Clozel
 * @see ConditionalOnEnabledResourceChain
 */
class OnEnabledResourceChainCondition extends SpringBootCondition {

	private static final String WEBJAR_ASSET_LOCATOR = "org.webjars.WebJarAssetLocator";

	private static final String WEBJAR_VERSION_LOCATOR = "org.webjars.WebJarVersionLocator";

	@Override
	public ConditionOutcome getMatchOutcome(ConditionContext context, AnnotatedTypeMetadata metadata) {
		ConfigurableEnvironment environment = (ConfigurableEnvironment) context.getEnvironment();
		boolean fixed = getEnabledProperty(environment, "strategy.fixed.", false);
		boolean content = getEnabledProperty(environment, "strategy.content.", false);
		Boolean chain = getEnabledProperty(environment, "", null);
		Boolean match = Chain.getEnabled(fixed, content, chain);
		ConditionMessage.Builder message = ConditionMessage.forCondition(ConditionalOnEnabledResourceChain.class);
		if (match == null) {
			if (ClassUtils.isPresent(WEBJAR_VERSION_LOCATOR, getClass().getClassLoader())) {
				return ConditionOutcome.match(message.found("class").items(WEBJAR_VERSION_LOCATOR));
			}
			if (ClassUtils.isPresent(WEBJAR_ASSET_LOCATOR, getClass().getClassLoader())) {
				return ConditionOutcome.match(message.found("class").items(WEBJAR_ASSET_LOCATOR));
			}
			return ConditionOutcome.noMatch(message.didNotFind("class").items(WEBJAR_VERSION_LOCATOR));
		}
		if (match) {
			return ConditionOutcome.match(message.because("enabled"));
		}
		return ConditionOutcome.noMatch(message.because("disabled"));
	}

	@Contract("_, _, !null -> !null")
	private @Nullable Boolean getEnabledProperty(ConfigurableEnvironment environment, String key,
			@Nullable Boolean defaultValue) {
		String name = "spring.web.resources.chain." + key + "enabled";
		if (defaultValue == null) {
			return environment.getProperty(name, Boolean.class);
		}
		return environment.getProperty(name, Boolean.class, defaultValue);
	}

}
