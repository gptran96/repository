/*
 * Copyright 2012-present the original author or authors.
 */

package org.springframework.boot.autoconfigure.web;

import java.util.List;

import org.jspecify.annotations.Nullable;

import org.springframework.aot.hint.RuntimeHints;
import org.springframework.aot.hint.RuntimeHintsRegistrar;

/**
 * {@link RuntimeHintsRegistrar} for default locations of web resources.
 *
 * @author Stephane Nicoll
 * @since 3.0.0
 */
public class WebResourcesRuntimeHints implements RuntimeHintsRegistrar {

	private static final List<String> DEFAULT_LOCATIONS = List.of("META-INF/resources/", "resources/", "static/",
			"public/");

	@Override
	public void registerHints(RuntimeHints hints, @Nullable ClassLoader classLoader) {
		ClassLoader classLoaderToUse = (classLoader != null) ? classLoader : getClass().getClassLoader();
		String[] locations = DEFAULT_LOCATIONS.stream()
			.filter((candidate) -> classLoaderToUse.getResource(candidate) != null)
			.map((location) -> location + "**")
			.toArray(String[]::new);
		if (locations.length > 0) {
			hints.resources().registerPattern((hint) -> hint.includes(locations));
		}
	}

}
