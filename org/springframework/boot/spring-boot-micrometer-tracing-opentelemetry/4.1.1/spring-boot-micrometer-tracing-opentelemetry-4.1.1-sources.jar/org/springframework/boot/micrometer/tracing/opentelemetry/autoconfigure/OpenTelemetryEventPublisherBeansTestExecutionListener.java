/*
 * Copyright 2012-present the original author or authors.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.springframework.boot.micrometer.tracing.opentelemetry.autoconfigure;

import org.junit.platform.launcher.TestExecutionListener;
import org.junit.platform.launcher.TestIdentifier;

/**
 * JUnit {@link TestExecutionListener} to ensure
 * {@link OpenTelemetryEventPublisherBeansApplicationListener#addWrapper()} is called as
 * early as possible.
 *
 * @author Phillip Webb
 * @since 4.0.0
 * @see OpenTelemetryEventPublisherBeansApplicationListener
 */
public class OpenTelemetryEventPublisherBeansTestExecutionListener implements TestExecutionListener {

	@Override
	public void executionStarted(TestIdentifier testIdentifier) {
		OpenTelemetryEventPublisherBeansApplicationListener.addWrapper();
	}

}
