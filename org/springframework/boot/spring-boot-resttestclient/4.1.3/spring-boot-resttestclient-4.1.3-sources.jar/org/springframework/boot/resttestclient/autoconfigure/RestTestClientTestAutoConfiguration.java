/*
 * Copyright 2012-present the original author or authors.
 */

package org.springframework.boot.resttestclient.autoconfigure;

import org.springframework.beans.factory.NoSuchBeanDefinitionException;
import org.springframework.beans.factory.ObjectProvider;
import org.springframework.boot.autoconfigure.AutoConfiguration;
import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.http.converter.autoconfigure.ClientHttpMessageConvertersCustomizer;
import org.springframework.boot.test.http.server.LocalTestWebServer;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.client.RestTestClient;
import org.springframework.web.client.RestClient;
import org.springframework.web.context.WebApplicationContext;

/**
 * Test auto-configuration for {@link RestTestClient}.
 *
 * @author Stephane Nicoll
 * @author Andy Wilkinson
 * @author Phillip Webb
 * @see AutoConfigureRestTestClient
 */
@AutoConfiguration
@ConditionalOnClass({ RestClient.class, RestTestClient.class, ClientHttpMessageConvertersCustomizer.class })
final class RestTestClientTestAutoConfiguration {

	@Bean
	SpringBootRestTestClientBuilderCustomizer springBootRestTestClientBuilderCustomizer(
			ObjectProvider<ClientHttpMessageConvertersCustomizer> httpMessageConverterCustomizers) {
		return new SpringBootRestTestClientBuilderCustomizer(httpMessageConverterCustomizers.orderedStream().toList());
	}

	@Bean
	@ConditionalOnMissingBean
	RestTestClient restTestClient(WebApplicationContext applicationContext,
			ObjectProvider<RestTestClientBuilderCustomizer> customizers) {
		RestTestClient.Builder<?> builder = getBuilder(applicationContext);
		customizers.orderedStream().forEach((customizer) -> customizer.customize(builder));
		return builder.build();
	}

	private RestTestClient.Builder<?> getBuilder(WebApplicationContext applicationContext) {
		LocalTestWebServer localTestWebServer = LocalTestWebServer.get(applicationContext);
		if (localTestWebServer != null) {
			return RestTestClient.bindToServer().uriBuilderFactory(localTestWebServer.uriBuilderFactory());
		}
		if (hasBean(applicationContext, MockMvc.class)) {
			return RestTestClient.bindTo(applicationContext.getBean(MockMvc.class));
		}
		return RestTestClient.bindToApplicationContext(applicationContext);
	}

	private boolean hasBean(ApplicationContext applicationContext, Class<?> type) {
		try {
			applicationContext.getBean(type);
			return true;
		}
		catch (NoSuchBeanDefinitionException ex) {
			return false;
		}
	}

}
