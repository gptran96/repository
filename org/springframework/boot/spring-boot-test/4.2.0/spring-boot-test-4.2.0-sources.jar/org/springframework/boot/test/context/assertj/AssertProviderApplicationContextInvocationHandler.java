/*
 * Copyright 2012-present the original author or authors.
 */

package org.springframework.boot.test.context.assertj;

import java.io.Closeable;
import java.io.IOException;
import java.lang.reflect.InvocationHandler;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.Arrays;
import java.util.function.Supplier;

import org.jspecify.annotations.Nullable;

import org.springframework.context.ApplicationContext;
import org.springframework.core.style.ToStringCreator;
import org.springframework.util.Assert;
import org.springframework.util.ObjectUtils;

/**
 * {@link InvocationHandler} used by {@link ApplicationContextAssertProvider} generated
 * proxies.
 *
 * @author Phillip Webb
 */
class AssertProviderApplicationContextInvocationHandler implements InvocationHandler {

	private final Class<?> applicationContextType;

	private final @Nullable ApplicationContext applicationContext;

	private final @Nullable RuntimeException startupFailure;

	AssertProviderApplicationContextInvocationHandler(Class<?> applicationContextType, Supplier<?> contextSupplier) {
		this.applicationContextType = applicationContextType;
		Object contextOrStartupFailure = getContextOrStartupFailure(contextSupplier);
		if (contextOrStartupFailure instanceof RuntimeException runtimeException) {
			this.applicationContext = null;
			this.startupFailure = runtimeException;
		}
		else {
			this.applicationContext = (ApplicationContext) contextOrStartupFailure;
			this.startupFailure = null;
		}
	}

	private Object getContextOrStartupFailure(Supplier<?> contextSupplier) {
		try {
			return contextSupplier.get();
		}
		catch (RuntimeException ex) {
			return ex;
		}
	}

	@Override
	public @Nullable Object invoke(Object proxy, Method method, Object[] args) throws Throwable {
		if (isToString(method)) {
			return toString();
		}
		if (isGetSourceContext(method)) {
			return getSourceContext(args);
		}
		if (isGetStartupFailure(method)) {
			return getStartupFailure();
		}
		if (isAssertThat(method)) {
			return getAssertThat(proxy);
		}
		if (isCloseMethod(method)) {
			return invokeClose();
		}
		return invokeApplicationContextMethod(method, args);
	}

	private boolean isToString(Method method) {
		return ("toString".equals(method.getName()) && method.getParameterCount() == 0);
	}

	@Override
	public String toString() {
		if (this.startupFailure != null) {
			return "Unstarted application context " + this.applicationContextType.getName() + "[startupFailure="
					+ this.startupFailure.getClass().getName() + "]";
		}
		Assert.state(this.applicationContext != null, "'applicationContext' must not be null");
		ToStringCreator builder = new ToStringCreator(this.applicationContext)
			.append("id", this.applicationContext.getId())
			.append("applicationName", this.applicationContext.getApplicationName())
			.append("beanDefinitionCount", this.applicationContext.getBeanDefinitionCount());
		return "Started application " + builder;
	}

	private boolean isGetSourceContext(Method method) {
		return "getSourceApplicationContext".equals(method.getName()) && ((method.getParameterCount() == 0)
				|| Arrays.equals(new Class<?>[] { Class.class }, method.getParameterTypes()));
	}

	private Object getSourceContext(Object[] args) {
		ApplicationContext context = getStartedApplicationContext();
		if (!ObjectUtils.isEmpty(args)) {
			Assert.isInstanceOf((Class<?>) args[0], context);
		}
		return context;
	}

	private boolean isGetStartupFailure(Method method) {
		return ("getStartupFailure".equals(method.getName()) && method.getParameterCount() == 0);
	}

	private @Nullable Object getStartupFailure() {
		return this.startupFailure;
	}

	private boolean isAssertThat(Method method) {
		return ("assertThat".equals(method.getName()) && method.getParameterCount() == 0);
	}

	private Object getAssertThat(Object proxy) {
		return new ApplicationContextAssert<>((ApplicationContext) proxy, this.startupFailure);
	}

	private boolean isCloseMethod(Method method) {
		return ("close".equals(method.getName()) && method.getParameterCount() == 0);
	}

	private @Nullable Object invokeClose() throws IOException {
		if (this.applicationContext instanceof Closeable closeable) {
			closeable.close();
		}
		return null;
	}

	private Object invokeApplicationContextMethod(Method method, Object[] args) throws Throwable {
		try {
			return method.invoke(getStartedApplicationContext(), args);
		}
		catch (InvocationTargetException ex) {
			throw ex.getTargetException();
		}
	}

	private ApplicationContext getStartedApplicationContext() {
		if (this.startupFailure != null) {
			throw new IllegalStateException(this + " failed to start", this.startupFailure);
		}
		Assert.state(this.applicationContext != null, "'applicationContext' must not be null");
		return this.applicationContext;
	}

}
