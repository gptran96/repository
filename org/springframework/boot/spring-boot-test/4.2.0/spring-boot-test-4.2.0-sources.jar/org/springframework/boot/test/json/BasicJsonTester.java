/*
 * Copyright 2012-present the original author or authors.
 */

package org.springframework.boot.test.json;

import java.io.File;
import java.io.InputStream;
import java.nio.charset.Charset;

import org.jspecify.annotations.Nullable;

import org.springframework.core.io.Resource;
import org.springframework.util.Assert;

/**
 * AssertJ based JSON tester that works with basic JSON strings. Allows testing of JSON
 * payloads created from any source, for example:<pre class="code">
 * public class ExampleObjectJsonTests {
 *
 *     private BasicJsonTester json = new BasicJsonTester(getClass());
 *
 *     &#064;Test
 *     public void testWriteJson() throws IOException {
 *         assertThat(json.from("example.json")).extractingJsonPathStringValue("@.name")
				.isEqualTo("Spring");
 *     }
 *
 * }
 * </pre>
 *
 * See {@link AbstractJsonMarshalTester} for more details.
 *
 * @author Phillip Webb
 * @author Andy Wilkinson
 * @since 1.4.0
 */
public class BasicJsonTester {

	private @Nullable JsonLoader loader;

	/**
	 * Create a new uninitialized {@link BasicJsonTester} instance.
	 */
	protected BasicJsonTester() {
	}

	/**
	 * Create a new {@link BasicJsonTester} instance that will load resources as UTF-8.
	 * @param resourceLoadClass the source class used to load resources
	 */
	public BasicJsonTester(Class<?> resourceLoadClass) {
		this(resourceLoadClass, null);
	}

	/**
	 * Create a new {@link BasicJsonTester} instance.
	 * @param resourceLoadClass the source class used to load resources
	 * @param charset the charset used to load resources
	 * @since 1.4.1
	 */
	public BasicJsonTester(Class<?> resourceLoadClass, @Nullable Charset charset) {
		Assert.notNull(resourceLoadClass, "'resourceLoadClass' must not be null");
		this.loader = new JsonLoader(resourceLoadClass, charset);
	}

	/**
	 * Initialize the marshal tester for use, configuring it to load JSON resources as
	 * UTF-8.
	 * @param resourceLoadClass the source class used when loading relative classpath
	 * resources
	 */
	protected final void initialize(Class<?> resourceLoadClass) {
		initialize(resourceLoadClass, null);
	}

	/**
	 * Initialize the marshal tester for use.
	 * @param resourceLoadClass the source class used when loading relative classpath
	 * resources
	 * @param charset the charset used when loading relative classpath resources
	 * @since 1.4.1
	 */
	protected final void initialize(Class<?> resourceLoadClass, @Nullable Charset charset) {
		if (this.loader == null) {
			this.loader = new JsonLoader(resourceLoadClass, charset);
		}
	}

	/**
	 * Create JSON content from the specified String source. The source can contain the
	 * JSON itself or, if it ends with {@code .json}, the name of a resource to be loaded
	 * using {@code resourceLoadClass}.
	 * @param source the JSON content or a {@code .json} resource name
	 * @return the JSON content
	 */
	public JsonContent<Object> from(CharSequence source) {
		JsonLoader loader = verify();
		return getJsonContent(loader, loader.getJson(source));
	}

	/**
	 * Create JSON content from the specified resource path.
	 * @param path the path of the resource to load
	 * @param resourceLoadClass the source class used to load the resource
	 * @return the JSON content
	 */
	public JsonContent<Object> from(String path, Class<?> resourceLoadClass) {
		JsonLoader loader = verify();
		return getJsonContent(loader, loader.getJson(path, resourceLoadClass));
	}

	/**
	 * Create JSON content from the specified JSON bytes.
	 * @param source the bytes of JSON
	 * @return the JSON content
	 */
	public JsonContent<Object> from(byte[] source) {
		JsonLoader loader = verify();
		return getJsonContent(loader, loader.getJson(source));
	}

	/**
	 * Create JSON content from the specified JSON file.
	 * @param source the file containing JSON
	 * @return the JSON content
	 */
	public JsonContent<Object> from(File source) {
		JsonLoader loader = verify();
		return getJsonContent(loader, loader.getJson(source));
	}

	/**
	 * Create JSON content from the specified JSON input stream.
	 * @param source the input stream containing JSON
	 * @return the JSON content
	 */
	public JsonContent<Object> from(InputStream source) {
		JsonLoader loader = verify();
		return getJsonContent(loader, loader.getJson(source));
	}

	/**
	 * Create JSON content from the specified JSON resource.
	 * @param source the resource containing JSON
	 * @return the JSON content
	 */
	public JsonContent<Object> from(Resource source) {
		JsonLoader loader = verify();
		return getJsonContent(loader, loader.getJson(source));
	}

	private JsonLoader verify() {
		Assert.state(this.loader != null, "Uninitialized BasicJsonTester");
		return this.loader;
	}

	private JsonContent<Object> getJsonContent(JsonLoader loader, String json) {
		return new JsonContent<>(loader.getResourceLoadClass(), null, json);
	}

}
