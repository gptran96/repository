/*
 * Copyright 2012-present the original author or authors.
 */

package org.springframework.boot.context.event;

import java.time.Duration;

import org.jspecify.annotations.Nullable;

import org.springframework.boot.ApplicationRunner;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.context.ConfigurableApplicationContext;

/**
 * Event published once the application context has been refreshed but before any
 * {@link ApplicationRunner application} and {@link CommandLineRunner command line}
 * runners have been called.
 *
 * @author Andy Wilkinson
 * @since 2.0.0
 */
@SuppressWarnings("serial")
public class ApplicationStartedEvent extends SpringApplicationEvent {

	private final ConfigurableApplicationContext context;

	private final @Nullable Duration timeTaken;

	/**
	 * Create a new {@link ApplicationStartedEvent} instance.
	 * @param application the current application
	 * @param args the arguments the application is running with
	 * @param context the context that was being created
	 * @param timeTaken the time taken to start the application
	 * @since 2.6.0
	 */
	public ApplicationStartedEvent(SpringApplication application, String[] args, ConfigurableApplicationContext context,
			@Nullable Duration timeTaken) {
		super(application, args);
		this.context = context;
		this.timeTaken = timeTaken;
	}

	/**
	 * Return the application context.
	 * @return the context
	 */
	public ConfigurableApplicationContext getApplicationContext() {
		return this.context;
	}

	/**
	 * Return the time taken to start the application, or {@code null} if unknown.
	 * @return the startup time
	 * @since 2.6.0
	 */
	public @Nullable Duration getTimeTaken() {
		return this.timeTaken;
	}

}
