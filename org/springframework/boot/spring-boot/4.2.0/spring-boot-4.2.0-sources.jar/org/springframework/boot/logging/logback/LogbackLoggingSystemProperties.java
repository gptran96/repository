/*
 * Copyright 2012-present the original author or authors.
 */

package org.springframework.boot.logging.logback;

import java.io.Console;
import java.util.function.BiConsumer;
import java.util.function.Function;

import ch.qos.logback.core.util.FileSize;
import org.jspecify.annotations.Nullable;

import org.springframework.boot.logging.LogFile;
import org.springframework.boot.logging.LoggingSystemProperties;
import org.springframework.core.convert.ConversionFailedException;
import org.springframework.core.convert.ConverterNotFoundException;
import org.springframework.core.env.Environment;
import org.springframework.core.env.PropertyResolver;
import org.springframework.util.ClassUtils;
import org.springframework.util.unit.DataSize;

/**
 * {@link LoggingSystemProperties} for Logback.
 *
 * @author Phillip Webb
 * @since 2.4.0
 * @see RollingPolicySystemProperty
 */
public class LogbackLoggingSystemProperties extends LoggingSystemProperties {

	private static final boolean JBOSS_LOGGING_PRESENT = ClassUtils.isPresent("org.jboss.logging.Logger",
			LogbackLoggingSystemProperties.class.getClassLoader());

	public LogbackLoggingSystemProperties(Environment environment) {
		super(environment);
	}

	/**
	 * Create a new {@link LogbackLoggingSystemProperties} instance.
	 * @param environment the source environment
	 * @param setter setter used to apply the property
	 * @since 2.4.3
	 */
	public LogbackLoggingSystemProperties(Environment environment,
			@Nullable BiConsumer<String, @Nullable String> setter) {
		super(environment, setter);
	}

	/**
	 * Create a new {@link LoggingSystemProperties} instance.
	 * @param environment the source environment
	 * @param defaultValueResolver function used to resolve default values or {@code null}
	 * @param setter setter used to apply the property or {@code null} for system
	 * properties
	 * @since 3.2.0
	 */
	public LogbackLoggingSystemProperties(Environment environment,
			@Nullable Function<@Nullable String, @Nullable String> defaultValueResolver,
			@Nullable BiConsumer<String, @Nullable String> setter) {
		super(environment, defaultValueResolver, setter);
	}

	@Override
	protected @Nullable Console getConsole() {
		return super.getConsole();
	}

	@Override
	protected void apply(@Nullable LogFile logFile, PropertyResolver resolver) {
		super.apply(logFile, resolver);
		applyJBossLoggingProperties();
		applyRollingPolicyProperties(resolver);
	}

	private void applyJBossLoggingProperties() {
		if (JBOSS_LOGGING_PRESENT) {
			setSystemProperty("org.jboss.logging.provider", "slf4j");
		}
	}

	private void applyRollingPolicyProperties(PropertyResolver resolver) {
		applyRollingPolicy(RollingPolicySystemProperty.FILE_NAME_PATTERN, resolver);
		applyRollingPolicy(RollingPolicySystemProperty.CLEAN_HISTORY_ON_START, resolver);
		applyRollingPolicy(RollingPolicySystemProperty.MAX_FILE_SIZE, resolver, DataSize.class);
		applyRollingPolicy(RollingPolicySystemProperty.TOTAL_SIZE_CAP, resolver, DataSize.class);
		applyRollingPolicy(RollingPolicySystemProperty.MAX_HISTORY, resolver);
	}

	private void applyRollingPolicy(RollingPolicySystemProperty property, PropertyResolver resolver) {
		applyRollingPolicy(property, resolver, String.class);
	}

	private <T> void applyRollingPolicy(RollingPolicySystemProperty property, PropertyResolver resolver,
			Class<T> type) {
		T value = getProperty(resolver, property.getApplicationPropertyName(), type);
		if (value != null) {
			String stringValue = String.valueOf((value instanceof DataSize dataSize) ? dataSize.toBytes() : value);
			setSystemProperty(property.getEnvironmentVariableName(), stringValue);
		}
	}

	@SuppressWarnings("unchecked")
	private <T> @Nullable T getProperty(PropertyResolver resolver, String key, Class<T> type) {
		try {
			return resolver.getProperty(key, type);
		}
		catch (ConversionFailedException | ConverterNotFoundException ex) {
			if (type != DataSize.class) {
				throw ex;
			}
			String value = resolver.getProperty(key);
			return (T) DataSize.ofBytes(FileSize.valueOf(value).getSize());
		}
	}

}
