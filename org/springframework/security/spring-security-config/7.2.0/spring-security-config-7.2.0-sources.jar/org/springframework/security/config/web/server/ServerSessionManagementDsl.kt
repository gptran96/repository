/*
 * Copyright 2004-present the original author or authors.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.springframework.security.config.web.server

/**
 * A Kotlin DSL to configure [ServerHttpSecurity] Session Management using idiomatic Kotlin code.
 *
 * @author Marcus da Coregio
 * @since 6.3
 */
@ServerSecurityMarker
class ServerSessionManagementDsl {
    private var sessionConcurrency: ((ServerHttpSecurity.SessionManagementSpec.ConcurrentSessionsSpec) -> Unit)? = null

    /**
     * Enables Session Management support.
     *
     * Example:
     *
     * ```
     * @Configuration
     * @EnableWebFluxSecurity
     * open class SecurityConfig {
     *
     *  @Bean
     *  open fun springWebFilterChain(http: ServerHttpSecurity): SecurityWebFilterChain {
     *      return http {
     *          sessionManagement {
     *              sessionConcurrency {
     *                  maximumSessions = { authentication -> Mono.just(1) }
     *              }
     *          }
     *       }
     *   }
     * }
     * ```
     *
     * @param backChannelConfig custom configurations to configure OIDC 1.0 Back-Channel Logout support
     * @see [ServerOidcBackChannelLogoutDsl]
     */
    fun sessionConcurrency(sessionConcurrencyConfig: ServerSessionConcurrencyDsl.() -> Unit) {
        this.sessionConcurrency = ServerSessionConcurrencyDsl().apply(sessionConcurrencyConfig).get()
    }

    internal fun get(): (ServerHttpSecurity.SessionManagementSpec) -> Unit {
        return { sessionManagement ->
            sessionConcurrency?.also { sessionManagement.concurrentSessions(sessionConcurrency) }
        }
    }
}
