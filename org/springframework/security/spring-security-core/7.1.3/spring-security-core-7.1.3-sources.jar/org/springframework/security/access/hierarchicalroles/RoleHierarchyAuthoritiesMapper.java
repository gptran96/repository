/*
 * Copyright 2004-present the original author or authors.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.springframework.security.access.hierarchicalroles;

import java.util.Collection;

import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.mapping.GrantedAuthoritiesMapper;

/**
 * A {@link GrantedAuthoritiesMapper} that maps authorities to their reachable authorities
 * using a {@link RoleHierarchy}.
 *
 * @author Luke Taylor
 */
public class RoleHierarchyAuthoritiesMapper implements GrantedAuthoritiesMapper {

	private final RoleHierarchy roleHierarchy;

	public RoleHierarchyAuthoritiesMapper(RoleHierarchy roleHierarchy) {
		this.roleHierarchy = roleHierarchy;
	}

	@Override
	public Collection<? extends GrantedAuthority> mapAuthorities(Collection<? extends GrantedAuthority> authorities) {
		return this.roleHierarchy.getReachableGrantedAuthorities(authorities);
	}

}
