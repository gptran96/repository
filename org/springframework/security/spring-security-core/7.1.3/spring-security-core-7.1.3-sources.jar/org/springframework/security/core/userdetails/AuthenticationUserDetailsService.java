/*
 * Copyright 2004-present the original author or authors.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.springframework.security.core.userdetails;

import org.springframework.security.core.Authentication;

/**
 * Interface that allows for retrieving a UserDetails object based on an
 * <tt>Authentication</tt> object.
 *
 * @author Ruud Senden
 * @since 2.0
 */
public interface AuthenticationUserDetailsService<T extends Authentication> {

	/**
	 * Loads the {@link UserDetails} for the given authentication token.
	 * @param token The pre-authenticated authentication token
	 * @return UserDetails for the given authentication token, never null.
	 * @throws UsernameNotFoundException if no user details can be found for the given
	 * authentication token
	 */
	UserDetails loadUserDetails(T token) throws UsernameNotFoundException;

}
