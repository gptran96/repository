/*
 * Copyright 2004-present the original author or authors.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.springframework.security.oauth2.server.authorization.jackson;

import java.util.Map;

import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.JsonAutoDetect.Visibility;
import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonTypeInfo;
import com.fasterxml.jackson.annotation.JsonTypeInfo.Id;

import org.springframework.security.oauth2.server.authorization.authentication.OAuth2TokenExchangeActor;

/**
 * This mixin class is used to serialize/deserialize {@link OAuth2TokenExchangeActor}.
 *
 * @author Steve Riesenberg
 * @since 7.0
 * @see OAuth2TokenExchangeActor
 */
@JsonTypeInfo(use = Id.CLASS)
@JsonAutoDetect(fieldVisibility = Visibility.ANY, getterVisibility = Visibility.NONE,
		isGetterVisibility = Visibility.NONE, creatorVisibility = Visibility.NONE)
abstract class OAuth2TokenExchangeActorMixin {

	@JsonCreator
	OAuth2TokenExchangeActorMixin(@JsonProperty("claims") Map<String, Object> claims) {
	}

}
