/*
 * Copyright 2004-present the original author or authors.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.springframework.security.oauth2.server.authorization.jackson2;

import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.JsonAutoDetect.Visibility;
import com.fasterxml.jackson.annotation.JsonTypeInfo;
import com.fasterxml.jackson.annotation.JsonTypeInfo.Id;

import org.springframework.security.oauth2.jose.jws.SignatureAlgorithm;

/**
 * This mixin class is used to serialize/deserialize {@link SignatureAlgorithm}.
 *
 * @author Joe Grandja
 * @since 7.0
 * @see SignatureAlgorithm
 * @deprecated as of 7.0 in favor of
 * {@code org.springframework.security.oauth2.server.authorization.jackson.JwsAlgorithmMixin}
 * based on Jackson 3
 */
@Deprecated(forRemoval = true)
@JsonTypeInfo(use = Id.CLASS)
@JsonAutoDetect(fieldVisibility = Visibility.ANY, getterVisibility = Visibility.NONE,
		isGetterVisibility = Visibility.NONE)
abstract class JwsAlgorithmMixin {

}
