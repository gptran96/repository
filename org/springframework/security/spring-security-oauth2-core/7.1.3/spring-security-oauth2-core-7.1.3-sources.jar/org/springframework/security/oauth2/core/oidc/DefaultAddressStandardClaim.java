/*
 * Copyright 2004-present the original author or authors.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.springframework.security.oauth2.core.oidc;

import java.util.Map;

import org.jspecify.annotations.Nullable;

/**
 * The default implementation of an {@link AddressStandardClaim Address Claim}.
 *
 * @author Joe Grandja
 * @since 5.0
 * @see AddressStandardClaim
 */
public final class DefaultAddressStandardClaim implements AddressStandardClaim {

	private @Nullable String formatted;

	private @Nullable String streetAddress;

	private @Nullable String locality;

	private @Nullable String region;

	private @Nullable String postalCode;

	private @Nullable String country;

	private DefaultAddressStandardClaim() {
	}

	@Override
	public @Nullable String getFormatted() {
		return this.formatted;
	}

	@Override
	public @Nullable String getStreetAddress() {
		return this.streetAddress;
	}

	@Override
	public @Nullable String getLocality() {
		return this.locality;
	}

	@Override
	public @Nullable String getRegion() {
		return this.region;
	}

	@Override
	public @Nullable String getPostalCode() {
		return this.postalCode;
	}

	@Override
	public @Nullable String getCountry() {
		return this.country;
	}

	@Override
	public boolean equals(@Nullable Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null || !AddressStandardClaim.class.isAssignableFrom(obj.getClass())) {
			return false;
		}
		AddressStandardClaim other = (AddressStandardClaim) obj;
		if ((this.getFormatted() != null) ? !this.getFormatted().equals(other.getFormatted())
				: other.getFormatted() != null) {
			return false;
		}
		if ((this.getStreetAddress() != null) ? !this.getStreetAddress().equals(other.getStreetAddress())
				: other.getStreetAddress() != null) {
			return false;
		}
		if ((this.getLocality() != null) ? !this.getLocality().equals(other.getLocality())
				: other.getLocality() != null) {
			return false;
		}
		if ((this.getRegion() != null) ? !this.getRegion().equals(other.getRegion()) : other.getRegion() != null) {
			return false;
		}
		if ((this.getPostalCode() != null) ? !this.getPostalCode().equals(other.getPostalCode())
				: other.getPostalCode() != null) {
			return false;
		}
		return (this.getCountry() != null) ? this.getCountry().equals(other.getCountry()) : other.getCountry() == null;
	}

	@Override
	public int hashCode() {
		int result = (this.getFormatted() != null) ? this.getFormatted().hashCode() : 0;
		result = 31 * result + ((this.getStreetAddress() != null) ? this.getStreetAddress().hashCode() : 0);
		result = 31 * result + ((this.getLocality() != null) ? this.getLocality().hashCode() : 0);
		result = 31 * result + ((this.getRegion() != null) ? this.getRegion().hashCode() : 0);
		result = 31 * result + ((this.getPostalCode() != null) ? this.getPostalCode().hashCode() : 0);
		result = 31 * result + ((this.getCountry() != null) ? this.getCountry().hashCode() : 0);
		return result;
	}

	/**
	 * A builder for {@link DefaultAddressStandardClaim}.
	 */
	public static class Builder {

		private static final String FORMATTED_FIELD_NAME = "formatted";

		private static final String STREET_ADDRESS_FIELD_NAME = "street_address";

		private static final String LOCALITY_FIELD_NAME = "locality";

		private static final String REGION_FIELD_NAME = "region";

		private static final String POSTAL_CODE_FIELD_NAME = "postal_code";

		private static final String COUNTRY_FIELD_NAME = "country";

		private @Nullable String formatted;

		private @Nullable String streetAddress;

		private @Nullable String locality;

		private @Nullable String region;

		private @Nullable String postalCode;

		private @Nullable String country;

		/**
		 * Default constructor.
		 */
		public Builder() {
		}

		/**
		 * Constructs and initializes the address attributes using the provided
		 * {@code addressFields}.
		 * @param addressFields the fields used to initialize the address attributes
		 */
		public Builder(Map<String, Object> addressFields) {
			this.formatted((String) addressFields.get(FORMATTED_FIELD_NAME));
			this.streetAddress((String) addressFields.get(STREET_ADDRESS_FIELD_NAME));
			this.locality((String) addressFields.get(LOCALITY_FIELD_NAME));
			this.region((String) addressFields.get(REGION_FIELD_NAME));
			this.postalCode((String) addressFields.get(POSTAL_CODE_FIELD_NAME));
			this.country((String) addressFields.get(COUNTRY_FIELD_NAME));
		}

		/**
		 * Sets the full mailing address, formatted for display.
		 * @param formatted the full mailing address, may be {@code null}
		 * @return the {@link Builder}
		 */
		public Builder formatted(@Nullable String formatted) {
			this.formatted = formatted;
			return this;
		}

		/**
		 * Sets the full street address, which may include house number, street name, P.O.
		 * Box, etc.
		 * @param streetAddress the full street address, may be {@code null}
		 * @return the {@link Builder}
		 */
		public Builder streetAddress(@Nullable String streetAddress) {
			this.streetAddress = streetAddress;
			return this;
		}

		/**
		 * Sets the city or locality.
		 * @param locality the city or locality, may be {@code null}
		 * @return the {@link Builder}
		 */
		public Builder locality(@Nullable String locality) {
			this.locality = locality;
			return this;
		}

		/**
		 * Sets the state, province, prefecture, or region.
		 * @param region the state, province, prefecture, or region, may be {@code null}
		 * @return the {@link Builder}
		 */
		public Builder region(@Nullable String region) {
			this.region = region;
			return this;
		}

		/**
		 * Sets the zip code or postal code.
		 * @param postalCode the zip code or postal code, may be {@code null}
		 * @return the {@link Builder}
		 */
		public Builder postalCode(@Nullable String postalCode) {
			this.postalCode = postalCode;
			return this;
		}

		/**
		 * Sets the country.
		 * @param country the country, may be {@code null}
		 * @return the {@link Builder}
		 */
		public Builder country(@Nullable String country) {
			this.country = country;
			return this;
		}

		/**
		 * Builds a new {@link DefaultAddressStandardClaim}.
		 * @return a {@link AddressStandardClaim}
		 */
		public AddressStandardClaim build() {
			DefaultAddressStandardClaim address = new DefaultAddressStandardClaim();
			address.formatted = this.formatted;
			address.streetAddress = this.streetAddress;
			address.locality = this.locality;
			address.region = this.region;
			address.postalCode = this.postalCode;
			address.country = this.country;
			return address;
		}

	}

}
