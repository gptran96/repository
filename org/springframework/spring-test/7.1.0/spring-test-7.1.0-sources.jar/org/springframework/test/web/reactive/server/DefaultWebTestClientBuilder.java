/*
 * Copyright 2002-present the original author or authors.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.springframework.test.web.reactive.server;

import java.time.Duration;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.Function;

import org.jspecify.annotations.Nullable;

import org.springframework.http.HttpHeaders;
import org.springframework.http.client.reactive.ClientHttpConnector;
import org.springframework.http.client.reactive.HttpComponentsClientHttpConnector;
import org.springframework.http.client.reactive.JdkClientHttpConnector;
import org.springframework.http.client.reactive.JettyClientHttpConnector;
import org.springframework.http.client.reactive.ReactorClientHttpConnector;
import org.springframework.http.codec.ClientCodecConfigurer;
import org.springframework.http.server.reactive.SslInfo;
import org.springframework.util.Assert;
import org.springframework.util.ClassUtils;
import org.springframework.util.CollectionUtils;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.ApiVersionInserter;
import org.springframework.web.reactive.function.client.ExchangeFilterFunction;
import org.springframework.web.reactive.function.client.ExchangeFunction;
import org.springframework.web.reactive.function.client.ExchangeFunctions;
import org.springframework.web.reactive.function.client.ExchangeStrategies;
import org.springframework.web.server.adapter.WebHttpHandlerBuilder;
import org.springframework.web.util.DefaultUriBuilderFactory;
import org.springframework.web.util.UriBuilderFactory;

/**
 * Default implementation of {@link WebTestClient.Builder}.
 *
 * @author Rossen Stoyanchev
 * @author Sam Brannen
 * @since 5.0
 */
class DefaultWebTestClientBuilder implements WebTestClient.Builder {

	private static final boolean REACTOR_NETTY_CLIENT_PRESENT;

	private static final boolean JETTY_CLIENT_PRESENT;

	private static final boolean HTTP_COMPONENTS_CLIENT_PRESENT;

	private static final boolean WEB_FLUX_PRESENT;

	static {
		ClassLoader loader = DefaultWebTestClientBuilder.class.getClassLoader();
		REACTOR_NETTY_CLIENT_PRESENT = ClassUtils.isPresent("reactor.netty.http.client.HttpClient", loader);
		JETTY_CLIENT_PRESENT =
				ClassUtils.isPresent("org.eclipse.jetty.client.HttpClient", loader) &&
						ClassUtils.isPresent("org.eclipse.jetty.reactive.client.ReactiveRequest", loader);
		HTTP_COMPONENTS_CLIENT_PRESENT =
				ClassUtils.isPresent("org.apache.hc.client5.http.impl.async.CloseableHttpAsyncClient", loader) &&
						ClassUtils.isPresent("org.apache.hc.core5.reactive.ReactiveDataConsumer", loader);
		WEB_FLUX_PRESENT = ClassUtils.isPresent(
				"org.springframework.web.reactive.function.client.ExchangeFunction", loader);
	}


	private final @Nullable WebHttpHandlerBuilder httpHandlerBuilder;

	private @Nullable ClientHttpConnector connector;

	private @Nullable SslInfo sslInfo;

	private @Nullable String baseUrl;

	private @Nullable UriBuilderFactory uriBuilderFactory;

	private @Nullable HttpHeaders defaultHeaders;

	private @Nullable LinkedMultiValueMap<String, String> defaultCookies;

	private @Nullable Object defaultApiVersion;

	private @Nullable ApiVersionInserter apiVersionInserter;

	private @Nullable List<ExchangeFilterFunction> filters;

	private Consumer<EntityExchangeResult<?>> entityResultConsumer = result -> {};

	private @Nullable ExchangeStrategies strategies;

	private @Nullable List<Consumer<ExchangeStrategies.Builder>> strategiesConfigurers;

	private @Nullable Duration responseTimeout;


	/** Determine connector via classpath detection. */
	DefaultWebTestClientBuilder() {
		this(null, null, null);
	}

	/** Use HttpHandlerConnector with mock server. */
	DefaultWebTestClientBuilder(WebHttpHandlerBuilder httpHandlerBuilder, @Nullable SslInfo sslInfo) {
		this(httpHandlerBuilder, null, sslInfo);
	}

	private DefaultWebTestClientBuilder(@Nullable WebHttpHandlerBuilder httpHandlerBuilder,
			@Nullable ClientHttpConnector connector, @Nullable SslInfo sslInfo) {

		Assert.isTrue(httpHandlerBuilder == null || connector == null,
				"Expected WebHttpHandlerBuilder or ClientHttpConnector but not both.");

		// Helpful message especially for MockMvcWebTestClient users
		Assert.state(WEB_FLUX_PRESENT,
				"To use WebTestClient, please add spring-webflux to the test classpath.");

		this.connector = connector;
		this.sslInfo = sslInfo;
		this.httpHandlerBuilder = (httpHandlerBuilder != null ? httpHandlerBuilder.clone() : null);
	}

	/** Copy constructor. */
	DefaultWebTestClientBuilder(DefaultWebTestClientBuilder other) {
		this.httpHandlerBuilder = (other.httpHandlerBuilder != null ? other.httpHandlerBuilder.clone() : null);
		this.connector = other.connector;
		this.sslInfo = other.sslInfo;
		this.responseTimeout = other.responseTimeout;

		this.baseUrl = other.baseUrl;
		this.uriBuilderFactory = other.uriBuilderFactory;
		this.defaultHeaders = (other.defaultHeaders != null ? HttpHeaders.copyOf(other.defaultHeaders) : null);
		this.defaultCookies = (other.defaultCookies != null ? other.defaultCookies.deepCopy() : null);
		this.defaultApiVersion = other.defaultApiVersion;
		this.apiVersionInserter = other.apiVersionInserter;
		this.filters = (other.filters != null ? new ArrayList<>(other.filters) : null);
		this.entityResultConsumer = other.entityResultConsumer;
		this.strategies = other.strategies;
		this.strategiesConfigurers = (other.strategiesConfigurers != null ?
				new ArrayList<>(other.strategiesConfigurers) : null);
	}


	@Override
	public WebTestClient.Builder baseUrl(String baseUrl) {
		this.baseUrl = baseUrl;
		return this;
	}

	@Override
	public WebTestClient.Builder uriBuilderFactory(UriBuilderFactory uriBuilderFactory) {
		this.uriBuilderFactory = uriBuilderFactory;
		return this;
	}

	@Override
	public WebTestClient.Builder defaultHeader(String header, String... values) {
		initHeaders().put(header, Arrays.asList(values));
		return this;
	}

	@Override
	public WebTestClient.Builder defaultHeaders(Consumer<HttpHeaders> headersConsumer) {
		headersConsumer.accept(initHeaders());
		return this;
	}

	private HttpHeaders initHeaders() {
		if (this.defaultHeaders == null) {
			this.defaultHeaders = new HttpHeaders();
		}
		return this.defaultHeaders;
	}

	@Override
	public WebTestClient.Builder defaultCookie(String cookie, String... values) {
		initCookies().addAll(cookie, Arrays.asList(values));
		return this;
	}

	@Override
	public WebTestClient.Builder defaultCookies(Consumer<MultiValueMap<String, String>> cookiesConsumer) {
		cookiesConsumer.accept(initCookies());
		return this;
	}

	private MultiValueMap<String, String> initCookies() {
		if (this.defaultCookies == null) {
			this.defaultCookies = new LinkedMultiValueMap<>(3);
		}
		return this.defaultCookies;
	}

	@Override
	public WebTestClient.Builder defaultApiVersion(Object version) {
		this.defaultApiVersion = version;
		return this;
	}

	@Override
	public WebTestClient.Builder apiVersionInserter(@Nullable ApiVersionInserter apiVersionInserter) {
		this.apiVersionInserter = apiVersionInserter;
		return this;
	}

	@Override
	public WebTestClient.Builder filter(ExchangeFilterFunction filter) {
		Assert.notNull(filter, "ExchangeFilterFunction is required");
		initFilters().add(filter);
		return this;
	}

	@Override
	public WebTestClient.Builder filters(Consumer<List<ExchangeFilterFunction>> filtersConsumer) {
		filtersConsumer.accept(initFilters());
		return this;
	}

	private List<ExchangeFilterFunction> initFilters() {
		if (this.filters == null) {
			this.filters = new ArrayList<>();
		}
		return this.filters;
	}

	@Override
	public WebTestClient.Builder entityExchangeResultConsumer(Consumer<EntityExchangeResult<?>> entityResultConsumer) {
		Assert.notNull(entityResultConsumer, "'entityResultConsumer' is required");
		this.entityResultConsumer = this.entityResultConsumer.andThen(entityResultConsumer);
		return this;
	}

	@Override
	public WebTestClient.Builder codecs(Consumer<ClientCodecConfigurer> configurer) {
		if (this.strategiesConfigurers == null) {
			this.strategiesConfigurers = new ArrayList<>(4);
		}
		this.strategiesConfigurers.add(builder -> builder.codecs(configurer));
		return this;
	}

	@Override
	public WebTestClient.Builder exchangeStrategies(ExchangeStrategies strategies) {
		this.strategies = strategies;
		return this;
	}

	@Override
	public WebTestClient.Builder apply(WebTestClientConfigurer configurer) {
		configurer.afterConfigurerAdded(this, this.httpHandlerBuilder, this.connector);
		return this;
	}

	@Override
	public WebTestClient.Builder responseTimeout(Duration timeout) {
		Assert.notNull(timeout, "Timeout must not be null");
		Assert.isTrue(!timeout.isNegative(), "Timeout must be a non-negative value");
		this.responseTimeout = timeout;
		return this;
	}

	@Override
	public WebTestClient.Builder clientConnector(ClientHttpConnector connector) {
		this.connector = connector;
		return this;
	}

	@Override
	public WebTestClient build() {
		ClientHttpConnector connectorToUse = this.connector;
		if (connectorToUse == null) {
			if (this.httpHandlerBuilder != null) {
				connectorToUse = new HttpHandlerConnector(this.httpHandlerBuilder.build(), this.sslInfo);
			}
		}
		if (connectorToUse == null) {
			connectorToUse = initConnector();
		}
		ExchangeStrategies exchangeStrategies = initExchangeStrategies();
		Function<ClientHttpConnector, ExchangeFunction> exchangeFactory = connector -> {
			ExchangeFunction exchange = ExchangeFunctions.create(connector, exchangeStrategies);
			if (CollectionUtils.isEmpty(this.filters)) {
				return exchange;
			}
			return this.filters.stream()
					.reduce(ExchangeFilterFunction::andThen)
					.map(filter -> filter.apply(exchange))
					.orElse(exchange);

		};
		return new DefaultWebTestClient(
				connectorToUse, exchangeStrategies, exchangeFactory, initUriBuilderFactory(),
				(this.defaultHeaders != null ? HttpHeaders.readOnlyHttpHeaders(HttpHeaders.copyOf(this.defaultHeaders)) : null),
				(this.defaultCookies != null ? CollectionUtils.unmodifiableMultiValueMap(this.defaultCookies.deepCopy()) : null),
				this.defaultApiVersion, this.apiVersionInserter, this.entityResultConsumer,
				this.responseTimeout, new DefaultWebTestClientBuilder(this));
	}

	private static ClientHttpConnector initConnector() {
		if (REACTOR_NETTY_CLIENT_PRESENT) {
			return new ReactorClientHttpConnector();
		}
		else if (JETTY_CLIENT_PRESENT) {
			return new JettyClientHttpConnector();
		}
		else if (HTTP_COMPONENTS_CLIENT_PRESENT) {
			return new HttpComponentsClientHttpConnector();
		}
		else {
			return new JdkClientHttpConnector();
		}
	}

	private ExchangeStrategies initExchangeStrategies() {
		if (CollectionUtils.isEmpty(this.strategiesConfigurers)) {
			return (this.strategies != null ? this.strategies : ExchangeStrategies.withDefaults());
		}
		ExchangeStrategies.Builder builder =
				(this.strategies != null ? this.strategies.mutate() : ExchangeStrategies.builder());
		this.strategiesConfigurers.forEach(configurer -> configurer.accept(builder));
		return builder.build();
	}

	private UriBuilderFactory initUriBuilderFactory() {
		if (this.uriBuilderFactory != null) {
			return this.uriBuilderFactory;
		}
		return (this.baseUrl != null ?
				new DefaultUriBuilderFactory(this.baseUrl) : new DefaultUriBuilderFactory());
	}
}
